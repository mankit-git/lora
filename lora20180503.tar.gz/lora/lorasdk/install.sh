#!/bin/bash
dir=`cd $(dirname "$0") & pwd`
dir_change=$(echo $dir | sed 's/\//\\\//g')
dir_p=${dir%/*}
dir_p_change=$(echo $dir_p | sed 's/\//\\\//g')
#lrgateway.service
cp -f ${dir}/lrgateway.service ${dir}/lrgateway.service.tmp
sed -i "s/^WorkingDirectory=packet_forwarder\/gps_pkt_fwd/WorkingDirectory=${dir_p_change}\/packet_forwarder\/gps_pkt_fwd/" ${dir}/lrgateway.service.tmp
sed -i "s/^ExecStartPre=packet_forwarder\/reset_pkt_fwd.sh start packet_forwarder\/gps_pkt_fwd\/local_conf.json/\
ExecStartPre=${dir_p_change}\/packet_forwarder\/reset_pkt_fwd.sh start ${dir_p_change}\/packet_forwarder\/gps_pkt_fwd\/local_conf.json/" ${dir}/lrgateway.service.tmp
sed -i "s/^ExecStart=packet_forwarder\/gps_pkt_fwd\/gps_pkt_fwd/ExecStart=${dir_p_change}\/packet_forwarder\/gps_pkt_fwd\/gps_pkt_fwd/" ${dir}/lrgateway.service.tmp
sed -i "s/^ExecStopPost=packet_forwarder\/reset_pkt_fwd.sh stop/ExecStopPost=${dir_p_change}\/packet_forwarder\/reset_pkt_fwd.sh stop/" ${dir}/lrgateway.service.tmp
#lorabridge.service
cp -f ${dir}/lorabridge.service ${dir}/lorabridge.service.tmp
sed -i "s/^WorkingDirectory=.*$/WorkingDirectory=${dir_change}/" ${dir}/lorabridge.service.tmp
sed -i "s/^ExecStart=senzflow-lorabridge/ExecStart=${dir_change}\/senzflow-lorabridge/" ${dir}/lorabridge.service.tmp
if ! [ -z "$1" ];then
        cert=$1
        if ! [ -f $cert ];then
                echo "cert file ${cert} is not exist."
                exit 1
        fi
        if ! [ "${cert:0:1}" == "/" ];then
                cert="${dir}/${cert}"
        fi
        cert_change=$(echo $cert | sed 's/\//\\\//g')
        sed -i "/^ExecStart=/ s/$/ --cert=${cert_change}/" ${dir}/lorabridge.service.tmp
fi
cp -f ${dir}/lorabridge.service.tmp /lib/systemd/system/lorabridge.service
cp -f ${dir}/lrgateway.service.tmp /lib/systemd/system/lrgateway.service
sed -i 's/^#ForwardToSyslog.*$/ForwardToSyslog=no/g' /etc/systemd/journald.conf
chmod +x ${dir}/senzflow-lorabridge

systemctl daemon-reload
systemctl restart systemd-journald
systemctl enable lorabridge
systemctl enable lrgateway
systemctl restart lrgateway
systemctl restart lorabridge

