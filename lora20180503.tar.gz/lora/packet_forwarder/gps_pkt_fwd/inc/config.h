#ifndef _LORAGW_CONFIGURATION_H
#define _LORAGW_CONFIGURATION_H
	#define LIBLORAGW_VERSION	"3.2.1"
	#define DEBUG_AUX	0
	#define DEBUG_SPI	0
	#define DEBUG_REG	0
	#define DEBUG_HAL	1
	#define DEBUG_GPS	0
	#define DEBUG_GPIO	
#endif
