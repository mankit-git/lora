#ifndef _SETUP_H_
#define _SETUP_H_


#include <stdio.h>

#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <syslog.h>

#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>


//#include    "../uemf.h"
//#include    "../wsIntrn.h"
#include	<signal.h>
#include	<unistd.h>
#include	<sys/wait.h>


// for socket select
//#include  <sys/types.h>  
//#include  <sys/times.h>  
//#include  <sys/select.h> 

#include <pthread.h>

#include "cmd_process.h"


#include <syslog.h>
#include "debug_setting.h"
#include "command_define.h"
#include "g_config_data.h"

#if 0
//#define trace(fmt, args...) do{printf("line %d : " fmt , __LINE__, ## args);} while(0)
#define trace(fmt, args...) do{syslog(LOG_SYSLOG | LOG_NOTICE, "line %d : " fmt , __LINE__, ## args);} while(0)
#else
#define trace(fmt, args...)
#endif

#if 0
//#define dbg() do { printf("[%s : line %d] \n", __FUNCTION__, __LINE__); } while(0);
#define dbg() do { syslog(LOG_SYSLOG | LOG_NOTICE, "[%s : line %d] \n", __FUNCTION__, __LINE__); } while(0);
#else
#define dbg()
#endif

void process_client_event(int sockfd);

#endif /* __SETUP_H__ */
