#ifndef _COMMAND_DEFINE_H
#define _COMMAND_DEFINE_H

//--------------------------------------------------------
// Header Include
//
//--------------------------------------------------------

//--------------------------------------------------------
// Common Symbol Defines
//
//--------------------------------------------------------

#define Command_Token							"Kaifa Inc. PDC "
#define Command_TimeSync_Token					"TimeSync"
#define Command_Reboot_Token					"Reboot"
#define Command_ClearBuf_Token					"ClrCfgBuf"
#define Server_Ack_Token						"ReceiveConfig"
#define Command_Delimiter						'K'
#define Command_Update_Delimiter				0x7f

#define COMMAND_TOKEN_LEN                       12
#define COMMAND_PARAM_LEN                       20 // this is optional command paramter, e.g. TimeSync --> "20180423 15:43:33"
#define SEARCH_COMMNAD_LEN						24
#define MESSAGE_COMMAND_LEN						80
#define UPDATE_COMMAND_LEN						1048

#define FINDER_SERVER_PORT						1215	//UDP(return 1048 bytes)
// ConfigSlave is using 1215 to receive ConfigMaster command(UDP: 60 / 1048 )
// UDP(60): 'clrCfgBuf'
// UDP(60): 'reset' ==> reset MCU

#define SEARCH_PAYLOAD_SIZE					    1024
#define UPDATE_PAYLOAD_SIZE					    1024



#define COMPANY_STRING_SIZE     				24
#define MODEL_NAME_STRING_SIZE			        16
#define DEVICE_NAME_STRING_SIZE                 16
#define SERIAL_NO_STRING_SIZE			        16
#define HW_ID_STRING_SIZE		        		16
#define PASSWORD_STRING_SIZE                    16
#define MAC_ADDRESS_SIZE				        6

#define VERSION_STRING_SIZE                     8
#define BUILT_DATE_STRING_SIZE                  16


//ConfigMaster Search Command
typedef struct
{
    unsigned char flag; // 'K'
    unsigned char mac_addr[MAC_ADDRESS_SIZE]; // device MAC address
    unsigned char seq_no; // 0 ~ 2, 3 packets in total
} __attribute__((packed)) CommandDelimiter;

typedef struct _DeviceConfigData {
   unsigned char  config_version;   //1, default 1
   unsigned char  dhcp;             //2, 0: disable, 1: enable, default:0
   unsigned char  mac_addr[MAC_ADDRESS_SIZE];      //8,
   char   device_name[DEVICE_NAME_STRING_SIZE];   //24, default LoRaGW
   char   serialno[SERIAL_NO_STRING_SIZE];     //40, 123456789012345   
   unsigned long ipaddr;   //44, MSB, network order. 192.168.0.2 ==> current
   unsigned long netmask;  //48,MSB --255.255.255.0 ==> current
   unsigned long gw;       //52, MSB -- 192.168.0.1 ==> current
   
   //Jeffrey2018.04.18: newly added
   unsigned long fixed_ip_config; //56,  book-keep as fixed IP (network mode) of IPv4 IP
   unsigned long fixed_netmask_config; //60,  subnet mask
   unsigned long fixed_gateway_config; //64, default gateway  
   //Jeffrey2018.04.18: newly added
   
   char   company[COMPANY_STRING_SIZE];      //64+ 24 = 88, MFG
   char   modelname[MODEL_NAME_STRING_SIZE];    // 88 + 16 = 104, MFG
   char   hwID[HW_ID_STRING_SIZE];         //104 + 16 = 120, MFG
   unsigned char version[VERSION_STRING_SIZE]; //120 + 8 = 128, decided by FW
   unsigned char built_date[BUILT_DATE_STRING_SIZE];  //144,  decided by FW
   unsigned char reserved[880];//1024
}  __attribute__((packed)) DeviceConfigData;

typedef struct _DeviceStatus {
    char current_datetime[COMMAND_PARAM_LEN];
} __attribute__((packed)) DeviceStatus;


typedef struct _ServiceInfo {
    unsigned long service_ip;
    unsigned short service_port;
    unsigned short service_type;
} ServiceInfo;

// ESP Manager <-- IP Serial Server : response of ClearBuffer
typedef struct _SearchCommand {
   unsigned char command_token[SEARCH_COMMNAD_LEN]; //16
   ServiceInfo service_info;    //16 + 8
} __attribute__((packed)) SearchCommand; //24


typedef struct {
	CommandDelimiter delimiter;
	unsigned char payload[SEARCH_PAYLOAD_SIZE];
    unsigned char checksum;
} __attribute__((packed)) SearchFormat;


//-- ConfigMaster Update Command
//
//===========================


// ConfigMaster --> ConfigSlave
typedef struct {
    char pni[16]; //16
    //unsigned char header_flag;
    //unsigned char mac_flag; 
    unsigned char mac_addr[MAC_ADDRESS_SIZE]; // 16 + 6 = 22
    unsigned char seq;	// 22 + 1 = 23
    unsigned char checksum; // 23 + 1 = 24
} __attribute__((packed)) UpdateHeader;


typedef struct {
	UpdateHeader header; // 24
	unsigned char payload[UPDATE_PAYLOAD_SIZE]; //24 + 1024 = 1048
} __attribute__((packed)) UpdateFormat;

//-- ConfigMaster ClearBuffer / Reset Command


// ConfigMaster --> ConfigSlave(update / reset / clrCfgBuf)
typedef struct _CmdMsg {
   char pni[16];   //16
   char reserved[2]; // 16 + 2 = 18
   char serialno[SERIAL_NO_STRING_SIZE]; // 18 + 16 = 34
   unsigned char mac_addr[MAC_ADDRESS_SIZE]; // 34 + 6 = 40
   char command[COMMAND_TOKEN_LEN]; //40 + 12 = 52(e.g. 'TimeSync', 'Reboot', 'clrCfgBuf' 
   char param[COMMAND_PARAM_LEN]; // 52+ 20 = 72 e.g. "20180423 15:34:33"
   ServiceInfo service_info; // 72 + 8 = 80
} __attribute__((packed)) CmdMsg;


// ConfigMaster <-- ConfigSlave : response of ClearBuffer
typedef struct _ServerAckMsg {
   unsigned char flag; // 1
   unsigned char mac_addr[MAC_ADDRESS_SIZE]; // 1 + 6 = 7
   unsigned char seq; // 7 + 1 = 8
   char msg[24]; // 8 + 24 = 32
} __attribute__((packed)) ServerAckMsg;


//--------------------------------------------------------
// Function Prototype Declaration
//
//--------------------------------------------------------



//--------------------------------------------------------
// External Symbol Reference
//
//--------------------------------------------------------


#endif
