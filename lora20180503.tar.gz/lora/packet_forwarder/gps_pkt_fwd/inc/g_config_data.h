#ifndef _G_CONFIG_DATA_H_
#define _G_CONFIG_DATA_H_

//--------------------------------------------------------
// Header Include
//
//--------------------------------------------------------

#include "command_define.h"


//--------------------------------------------------------
// Common Symbol Defines
//
//--------------------------------------------------------
#define DFT_CONFIG_VERSION              1
#define DFT_DHCP                        1 //0: fixed IP, 1: DHCP
#define DFT_DEVICE_NAME                 "DeviceName12345"  //16 bytes
#define DFT_SERIAL_NO                   "SerialNo1234567"  // 16 bytes
#define DFT_ACCOUNT_NAME				"admin"
#define DFT_ACCOUNT_PASSWORD            "" // all-zero

//#define DFT_NIC_NAME                                    "enp0s3"
#define DFT_NIC_NAME                   "eth0"
//#define DFT_WORKING_DIR              "/home/jeffrey/LoRa/findip/ipsetup"
#define DFT_WORKING_DIR                "/home/lora/ipsetup"

#define DFT_NETWORK_MODE				NM_DHCP_ENABLED
#define DFT_CURRENT_IP					0
#define DFT_CURRENT_NETMASK				0
#define DFT_CURRENT_GATEWAY				0
#define DFT_CURRENT_DNS1				0
#define DFT_CURRENT_DNS2				0
#define DFT_FIXED_IP					0xC0A80001 //192.168.0.1
#define DFT_FIXED_NETMASK               0xFFFFFF00 //255.255.255.0
#define DFT_FIXED_GATEWAY               0xC0A800FE //192.168.0.254
#define DFT_FIXED_DNS1					0x0
#define DFT_FIXED_DNS2					0x0

#define IP_ADDRESS_NOT_AVAILABLE        "0.0.0.0"


// MAC Address
#define DFT_CONSOLE_MODE                "" //not used
#define DFT_COMPANY_NAME                "KaiFa123456789012345678" //24 bytes
#define DFT_MODEL_NAME                  "Model_LoRa_GW12"  //16 bytes
#define DFT_HW_ID                       "HW_ID_123456789"  //16 bytes

#define DFT_VERSION					    "1.0.0.0"  // 8 bytes
#define DFT_BUILT_DATE					"==2018/04/20<==" // 16 bytes

//--------------------------------------------------------
// Common Type/Enum Type
//
//--------------------------------------------------------
typedef enum {
    RS_NOTOK = 0, RS_OK, RS_TIMEOUT, RS_CKS_ERR,               // checksum error
    RS_FULL,
    RS_CT128_DATA_RATE_ERR,
    RS_CT128_TEST_SET_ERR,
    RS_CARD_EMPTY,
    RS_X_CLK_LOSS_SET_ERR,
    RS_TYPE_MISMATCH_SET_ERR,
    RS_NO_MAP_ACK_RCVED_SET_ERR,
    RS_MAP_RCVED_SET_ERR,
    RS_BAD_VALUE
} RetStatus;


typedef enum {NM_DHCP_DISABLED, NM_DHCP_ENABLED, NUM_NM_MODE}
NetworkMode;

//--------------------------------------------------------
// Common Type/Structure Defines
//
//--------------------------------------------------------

typedef struct _HostConfig {
	unsigned char config_version;
        char company[COMPANY_STRING_SIZE];
        char model_name[MODEL_NAME_STRING_SIZE];
        char device_name[DEVICE_NAME_STRING_SIZE];
        char serial_no[SERIAL_NO_STRING_SIZE];
        char hw_id[HW_ID_STRING_SIZE];
        char password[PASSWORD_STRING_SIZE];
} HostConfig;


typedef struct _NetworkConfig {   
    unsigned char network_mode; //DHCP enable(1)/disable(0)
    unsigned char mac_addr[MAC_ADDRESS_SIZE]; // FW's MAC address
    unsigned long ip; //current IPv4 IP
    unsigned long netmask; // current IPv4 subnet mask
    unsigned long gateway; // current IPv4 default gateway
    unsigned long dns1;    // current IPv4 primary DNS
    unsigned long dns2;    // current Ipv4 secondary DNS
    unsigned long fixed_ip_config; // book-keep as fixed IP (network mode) of IPv4 IP
    unsigned long fixed_netmask_config; // subnet mask
    unsigned long fixed_gateway_config; // default gateway
    unsigned long fixed_dns1_config;    // primary DNS
    unsigned long fixed_dns2_config;    // secondary DNS
} NetworkConfig;

typedef struct _EqpConfig {
    HostConfig          host_config;
    NetworkConfig       network_config;
} EqpConfig;
//--------------------------------------------------------
// Common Type/Union Defines
//
//--------------------------------------------------------

//--------------------------------------------------------
// Function Prototype Declaration
//
//--------------------------------------------------------

void InitFactoryDefault(void);
void InitSystemConfig(void);
EqpConfig* saGetEqpConfigPtr(void);


//--------------------------------------------------------
// External Symbol Reference
//
//--------------------------------------------------------


#endif /* __G_CONFIG_DATA_H__ */
