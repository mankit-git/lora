#ifndef _JSON_RDWR_H_
#define _JSON_RDWR_H_

#ifdef  __cplusplus  
extern "C" {  
#endif  

#include "loragw_hal.h"
#include "loragw_gps.h"
#include "loragw_aux.h"
#include "parson.h"
#include "base64.h"
#include "cmd_process.h"
#include "debug_setting.h"
#include "command_define.h"
#include "g_config_data.h"

#define DEFAULT_SERVER		127.0.0.1 /* hostname also supported */
#define DEFAULT_PORT_UP		1780
#define DEFAULT_PORT_DW		1782
#define DEFAULT_KEEPALIVE	5	/* default time interval for downstream keep-alive packet */
#define DEFAULT_STAT		30	/* default time interval for statistics */
#define PUSH_TIMEOUT_MS		100
#define PULL_TIMEOUT_MS		200
#define GPS_REF_MAX_AGE		30	/* maximum admitted delay in seconds of GPS loss before considering latest GPS sync unusable */
#define FETCH_SLEEP_MS		10	/* nb of ms waited when a fetch return no packets */

#define MSG(args...)	printf(args) /* message that is destined to the user */
#define STRINGIFY(x)	#x
#define STR(x)			STRINGIFY(x)

typedef struct _SX1301config
{
	struct lgw_conf_board_s boardconf;
	struct lgw_conf_rxrf_s rfconf[2];
	struct lgw_conf_rxif_s ifconf[10];
	struct lgw_tx_gain_lut_s txlut;
}SX1301config;

struct _Gateway_Conf
{
	char gateway_ID[20];
	// char server_address[20]; 
	char serv_addr[64];
	// char serv_port_up[8];   /* server port for upstream traffic = STR(DEFAULT_PORT_UP),STR(DEFAULT_PORT_DW)*/
	// char serv_port_down[8]; /* server port for downstream traffic */
	int serv_port_up;
	int serv_port_down;
	int keepalive_time; /* send a PULL_DATA request every X seconds, negative = disabled */
	unsigned stat_interval;

	//struct timeval push_timeout_half;
	int timeout;

	bool fwd_valid_pkt; /* packets with PAYLOAD CRC OK are forwarded */
	bool fwd_error_pkt; /* packets with PAYLOAD CRC ERROR are NOT forwarded ={{0}, STR(DEFAULT_SERVER), 0, 0,DEFAULT_KEEPALIVE,
					DEFAULT_STAT, 0, true, false, false}*/
	bool fwd_nocrc_pkt;	
}gateway_config;

typedef struct _Gatewayconfig
{
	SX1301config SX1301_config;
	struct _Gateway_Conf gateway_config;

}Gatewayconfig;

Gatewayconfig* saGetGatewayconfig(void);

extern int parse_SX1301_configuration(const char * conf_file);

extern int parse_gateway_configuration(const char * conf_file);

extern void json_rdwr(Gatewayconfig *pGatewayconfig, EqpConfig *pEqpConfig);

#ifdef  __cplusplus  
}  
#endif  /* end of __cplusplus */  


#endif
