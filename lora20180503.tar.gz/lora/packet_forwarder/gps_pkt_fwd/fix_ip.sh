#/bin/bash
	echo "interface eth0" >> /etc/dhcpcd.conf
	echo "static ip_address=192.168.3.77" >> /etc/dhcpcd.conf
	echo "static domain_name_servers=255.255.255.0" >> /etc/dhcpcd.conf
	echo "static routers=192.168.3.254" >> /etc/dhcpcd.conf
