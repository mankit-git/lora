#include <string.h>
#include <stdio.h>
#include <unistd.h> // 
#include <arpa/inet.h> // for htonl()
#include <string.h>

#include <sys/socket.h> // for inet_ntoa()
#include <netinet/in.h>
//#include <arpa/inet.h>



#include "debug_setting.h"
#include "cmd_process.h"
#include "g_config_data.h"
#include "json_rdwr.h"


int pre_networkmode;
extern int exchange_flag;

//extern "C" void setConfigData(IpssConfigData *pConfigData);
void getDeviceConfig(DeviceConfigData *pDeviceData)
{
    //initialize structure
    //DeviceConfig myConfig;
    EqpConfig *pEqpConfig = saGetEqpConfigPtr(); 
    unsigned long network_address;

    DPRINTF(DPRINTF_EVT_NETWORK, "getDeviceConfig()\n");

#if 0
    //prepare wipss_config data
    pDeviceData->config_version = DFT_CONFIG_VERSION;

    pDeviceData->dhcp = pEqpConfig->wifi_config.network_mode;
    DPRINTF(DPRINTF_EVT_NETWORK, "pDeviceData->dhcp = %d\n",pDeviceData->dhcp);

    strcpy(pDeviceData->device_name, pEqpConfig->host_config.device_name);

    strcpy(pDeviceData->serialno, pEqpConfig->host_config.serial_no);

    strcpy(pDeviceData->company, pEqpConfig->host_config.company);
    
    strcpy(pDeviceData->modelname, pEqpConfig->host_config.model_name);
    
    strcpy(pDeviceData->hwID, pEqpConfig->host_config.hw_id);

    strcpy(pDeviceData->version, DFT_VERSION);

    strcpy(pDeviceData->built_date, DFT_BUILT_DATE);

    // ethernet MAC address
    memcpy(pDeviceData->mac_addr, pEqpConfig->wifi_config.mac_addr, MAC_ADDRESS_SIZE);

    
    if(pEqpConfig->wifi_config.network_mode == NM_DHCP_ENABLED){
        network_address = htonl(pEqpConfig->wifi_config.ip);        
    }
    else {
        network_address = htonl(pEqpConfig->wifi_config.fixed_ip_config);        
    }
    
    DPRINTF(DPRINTF_EVT_NETWORK, "IP = %08X\n", network_address);
    pDeviceData->ipaddr = network_address;
    pDeviceData->fixed_ip_config = htonl(pEqpConfig->wifi_config.fixed_ip_config);        

    // netmask
    //pConfigData->netmask = htonl(pEqpConfig->wifi_config.netmask);
    if(pEqpConfig->wifi_config.network_mode == NM_DHCP_ENABLED)
        network_address = htonl(pEqpConfig->wifi_config.netmask);
    else
        network_address = htonl(pEqpConfig->wifi_config.fixed_netmask_config);
    
    DPRINTF(DPRINTF_EVT_NETWORK, "NETMASK = %08X\n", network_address);
    pDeviceData->netmask = network_address;
    pDeviceData->fixed_netmask_config = network_address;

    // default gateway
    //pConfigData->gw = htonl(pEqpConfig->wifi_config.gateway);
    if(pEqpConfig->wifi_config.network_mode == NM_DHCP_ENABLED)
        network_address = htonl(pEqpConfig->wifi_config.gateway);
    else
        network_address = htonl(pEqpConfig->wifi_config.fixed_gateway_config);
    
    DPRINTF(DPRINTF_EVT_NETWORK, "GATEWAY = %08X\n", network_address);
    pDeviceData->gw = network_address;
    pDeviceData->fixed_gateway_config = network_address;
#else
    /*
    typedef struct _DeviceConfigData {
   unsigned char  config_version;   //1, default 1
   unsigned char  dhcp;             //2, 0: disable, 1: enable, default:0
   unsigned char  mac_addr[6];      //8,
   char   device_name[16];   //24, default LoRaGW
   char   serialno[16];     //40, 123456789012345   
   unsigned long ipaddr;   //44, MSB, network order. 192.168.0.2 ==> current
   unsigned long netmask;  //48,MSB --255.255.255.0 ==> current
   unsigned long gw;       //52, MSB -- 192.168.0.1 ==> current
   
   //Jeffrey2018.04.18: newly added
   unsigned long fixed_ip_config; //56,  book-keep as fixed IP (network mode) of IPv4 IP
   unsigned long fixed_netmask_config; //60,  subnet mask
   unsigned long fixed_gateway_config; //64, default gateway  
   //Jeffrey2018.04.18: newly added
   
   char   company[24];      //88, MFG
   char   modelname[16];    //104, MFG
   char   hwID[16];         //120, MFG
   unsigned char version[8]; //128, decided by FW
   unsigned char built_date[16];  //144,  decided by FW
   unsigned char reserved[880];//1024
}  __attribute__((packed)) DeviceConfigData;
    */
    int i;
    unsigned long *pNetworkAddress;
    unsigned char *pDataPtr = (unsigned char *)pDeviceData;
    *pDataPtr = DFT_CONFIG_VERSION;
    pDataPtr += 1;
    *pDataPtr = pEqpConfig->network_config.network_mode;
    pDataPtr += 1;

    for(i = 0; i < 6 ; i++){
        *(pDataPtr + i) = pEqpConfig->network_config.mac_addr[i];
    }
    pDataPtr += 6;
    //device_name[16]
    memcpy(pDataPtr, pEqpConfig->host_config.device_name, 16);
    pDataPtr += 16;

    //serialno[16];
    memcpy(pDataPtr, pEqpConfig->host_config.serial_no, 16);
    pDataPtr += 16;

    pNetworkAddress = (unsigned long *)pDataPtr;
    // ipaddr, netmask, gw, fixed_ip_config, fixed_netmask_config, fixed_gateway_config    
    network_address = htonl(pEqpConfig->network_config.ip);
    memcpy(pNetworkAddress, &network_address, 4);
    pNetworkAddress += 1;

    network_address = htonl(pEqpConfig->network_config.netmask);
    memcpy(pNetworkAddress, &network_address, 4);
    pNetworkAddress += 1;

    network_address = htonl(pEqpConfig->network_config.gateway);
    memcpy(pNetworkAddress, &network_address, 4);
    pNetworkAddress += 1;

    network_address = htonl(pEqpConfig->network_config.fixed_ip_config);
    memcpy(pNetworkAddress, &network_address, 4);
    pNetworkAddress += 1;

    network_address = htonl(pEqpConfig->network_config.fixed_netmask_config);
    memcpy(pNetworkAddress, &network_address, 4);
    pNetworkAddress += 1;

    network_address = htonl(pEqpConfig->network_config.fixed_gateway_config);
    memcpy(pNetworkAddress, &network_address, 4);
    pNetworkAddress += 1;

    // locate unsigned char pointer to 'company' address
    pDataPtr = (unsigned char *)pDeviceData;
    pDataPtr += 64;
    
    // company[24]
    memcpy(pDataPtr, pEqpConfig->host_config.company, COMPANY_STRING_SIZE);
    pDataPtr += COMPANY_STRING_SIZE;

    // modelname[16]
    memcpy(pDataPtr, pEqpConfig->host_config.model_name, MODEL_NAME_STRING_SIZE);
    pDataPtr += MODEL_NAME_STRING_SIZE;

    // hwID[16]
    memcpy(pDataPtr, pEqpConfig->host_config.hw_id, HW_ID_STRING_SIZE);
    pDataPtr += HW_ID_STRING_SIZE;

    // version[8]
    strcpy((char *)pDataPtr, (const char *)DFT_VERSION);
    pDataPtr += VERSION_STRING_SIZE;

    // built_date[16]
    strcpy((char *)pDataPtr, (const char *)DFT_BUILT_DATE);
    pDataPtr += BUILT_DATE_STRING_SIZE;
                                                            
    // reserved[880]
    memset(pDataPtr, 0, 880);


#endif
    return;
}

void setDeviceConfig(DeviceConfigData *pDeviceData)
{
    unsigned char fixip_buffer[50];
	unsigned char fixgateway_buffer[50];
    char read_buf[1024];
    struct sockaddr_in addr1;

    DPRINTF(DPRINTF_EVT_NETWORK, "setDeviceConfig()\n");

    EqpConfig *pEqpConfig = saGetEqpConfigPtr();
    DPRINTF(DPRINTF_EVT_NETWORK, "setGetGatewayconfig()\n");
    Gatewayconfig *pGatewayconfig = saGetGatewayconfig();
    
    DPRINTF(DPRINTF_EVT_NETWORK, "bzero(read_buf, sizeof(read_buf));\n");
	bzero(read_buf, sizeof(read_buf));
	
    DPRINTF(DPRINTF_EVT_NETWORK, "fix_ip.txt\n");
	//FILE *fp_fixip = fopen("fix_ip.txt", "r+");
    FILE *fp_fixip = fopen("fix_ip.sh", "r+");

    DPRINTF(DPRINTF_EVT_NETWORK, "setvbuf\n");
	//setvbuf(fp_fixip, NULL, _IONBF, 0);
	
    DPRINTF(DPRINTF_EVT_NETWORK, "pre_netwrokmode\n");
	pre_networkmode = pEqpConfig->network_config.network_mode;
    DPRINTF(DPRINTF_EVT_NETWORK, "pEqpConfig->network_config.network_mode\n");
    pEqpConfig->network_config.network_mode = pDeviceData->dhcp;
	printf("***pre_networkmode:%d****\n", pre_networkmode);

	printf("---later_networkmode:%d---\n", pEqpConfig->network_config.network_mode);


    
    //unsigned char *pDataPtr;
    //unsigned long network_address;
    
    // config_version
    //strcpy(pEqpConfig->host_config.config_version, pDeviceData->config_version);
    //dhcp
    if(pDeviceData->dhcp == NM_DHCP_ENABLED){
        DPRINTF(DPRINTF_EVT_NETWORK, "[SET]dhcp(%d):enabled\n", pDeviceData->dhcp);
    }
    else {
        DPRINTF(DPRINTF_EVT_NETWORK, "[SET]dhcp(%d):disabled\n", pDeviceData->dhcp);
    }

    pEqpConfig->network_config.network_mode = pDeviceData->dhcp;
    //device_name
    DPRINTF(DPRINTF_EVT_NETWORK, "[SET]device_name = %s\n", pDeviceData->device_name);
    memcpy(pEqpConfig->host_config.device_name, pDeviceData->device_name, DEVICE_NAME_STRING_SIZE);
    //serialno
    //strcpy(pEqpConfig->host_config.serial_no, pDeviceData->serialno);
    if(pEqpConfig->network_config.network_mode == NM_DHCP_DISABLED){
        pEqpConfig->network_config.fixed_ip_config = ntohl(pDeviceData->fixed_ip_config);
        pEqpConfig->network_config.fixed_netmask_config = ntohl(pDeviceData->fixed_netmask_config);
        pEqpConfig->network_config.fixed_gateway_config = ntohl(pDeviceData->fixed_gateway_config);
         if(pre_networkmode != pEqpConfig->network_config.network_mode)
	    {   
            exchange_flag = 1;
            //DPRINTF(DPRINTF_EVT_NETWORK, "fixed_ip = %s\n", inet_ntoa(ntohl(pEqpConfig->wifi_config.fixed_ip_config)));
            //DPRINTF(DPRINTF_EVT_NETWORK, "fixed_netmask = %s\n", inet_ntoa(ntohl(pEqpConfig->wifi_config.fixed_netmask_config)));
            //DPRINTF(DPRINTF_EVT_NETWORK, "fixed_gateway = %s\n", inet_ntoa(ntohl(pEqpConfig->wifi_config.fixed_gateway_config)));

            // ofstream ofs;
            // ofs.ipen("../global_conf.json", ios::app);
            // assert(ofs.is_open());

            // Json::Reader reader;
            // Json::Value root;

            // if(!reader.parse(ifs, root, false))
            //     return -1;
            // root["network_mode"].asInt() = pEqpConfig->wifi_config.network_mode;
            // cout << root["network_mode"].asInt() << endl;

            DPRINTF(DPRINTF_EVT_NETWORK, "***********json_rdwr*********\n");
            json_rdwr(pGatewayconfig, pEqpConfig);

            system("sudo cp /etc/dhcpcd.conf /etc/dhcpcd.conf.bak");
            system("sudo cp /etc/dhcpcd.conf.bak /etc/dhcpcd.conf");
            fprintf(fp_fixip, "#/bin/bash\n");
            fprintf(fp_fixip, "\techo \"interface eth0\" >> /etc/dhcpcd.conf\n");

            //fprintf(fp_fixip, "\techo \"static ip_address=%s\" >> /etc/dhcpcd.conf\n", inet_ntoa(ntohl(pEqpConfig->network_config.fixed_ip_config)));
            addr1.sin_addr.s_addr = ntohl(pEqpConfig->network_config.fixed_ip_config);            
            fprintf(fp_fixip, "\techo \"static ip_address=%s\" >> /etc/dhcpcd.conf\n", inet_ntoa(addr1.sin_addr));

            addr1.sin_addr.s_addr = ntohl(pEqpConfig->network_config.fixed_netmask_config);
            fprintf(fp_fixip, "\techo \"static domain_name_servers=%s\" >> /etc/dhcpcd.conf\n", inet_ntoa(addr1.sin_addr));
            //fprintf(fp_fixip, "\techo \"static domain_name_servers=%s\" >> /etc/dhcpcd.conf\n", inet_ntoa(ntohl(pEqpConfig->network_config.fixed_netmask_config)));
            addr1.sin_addr.s_addr = ntohl(pEqpConfig->network_config.fixed_gateway_config);
            fprintf(fp_fixip, "\techo \"static routers=%s\" >> /etc/dhcpcd.conf\n", inet_ntoa(addr1.sin_addr));
            //fprintf(fp_fixip, "\techo \"static routers=%s\" >> /etc/dhcpcd.conf\n", inet_ntoa(ntohl(pEqpConfig->network_config.fixed_gateway_config)));
            printf("******set fix_ip OK*******\n");
            fflush(fp_fixip);
            fclose(fp_fixip);
            system("./fix_ip.sh");

        }
    }
    else {
        if(pre_networkmode != pEqpConfig->network_config.network_mode)
	    { 
            //printf("fix_ip:%s\n", inet_ntoa(pEqpConfig->network_config.fixed_ip_config));
            addr1.sin_addr.s_addr = pDeviceData->ipaddr;
            //printf("del fix_ip:%s\n", inet_ntoa(pDeviceData->ipaddr));
            sprintf(fixip_buffer, "sudo ip addr del %s dev eth0", inet_ntoa(addr1.sin_addr));
            system(fixip_buffer);
            //printf("del fix_ip gateway:%s\n", inet_ntoa(pDeviceData->gw));
            addr1.sin_addr.s_addr = pDeviceData->gw;
            sprintf(fixip_buffer, "sudo ip addr del %s dev eth0", inet_ntoa(addr1.sin_addr));
            //sprintf(fixgateway_buffer, "sudo ip route del %s dev eth0", inet_ntoa(pDeviceData->gw));
            system(fixgateway_buffer);
            system("cp /etc/dhcpcd.conf.bak /etc/dhcpcd.conf");
            exchange_flag = 2;  
        }
        printf("***********json_rdwr*********\n");
        json_rdwr(pGatewayconfig, pEqpConfig);
    }
    #if 0
    // We still have struct 'packed' issue, try copy the payload byte-by-byte
    pDataPtr = &(pConfigData->ipaddr); // Ankor point ipaddr(pos 50)    
    if(pEqpConfig->network_config.network_mode == NM_DHCP_DISABLED){        
    	pEqpConfig->network_config.fixed_ip_config = ntohl(pConfigData->ipaddr);
    	//pEqpConfig->network_config.fixed_netmask_config = ntohl(pConfigData->netmask);
    	//pEqpConfig->network_config.fixed_gateway_config = ntohl(pConfigData->gw);
        pDataPtr += 4; // netmask
        memcpy(&network_address, pDataPtr, 4);
        pEqpConfig->network_config.fixed_netmask_config = ntohl(network_address);
        pDataPtr += 4; // gateway
        memcpy(&network_address, pDataPtr, 4);
        pEqpConfig->network_config.fixed_gateway_config = ntohl(network_address);
        pDataPtr += 4; // to next field, e.g. mac_addr
        DPRINTF(DPRINTF_EVT_NETWORK, "fixed_ip = %08X\n", pEqpConfig->network_config.fixed_ip_config);
        DPRINTF(DPRINTF_EVT_NETWORK, "fixed_netmask = %08X\n", pEqpConfig->network_config.fixed_netmask_config);
        DPRINTF(DPRINTF_EVT_NETWORK, "fixed_gateway = %08X\n", pEqpConfig->network_config.fixed_gateway_config);
    }

    DPRINTF(DPRINTF_EVT_NETWORK, "dhcp = %d\n", pEqpConfig->network_config.network_mode);
    DPRINTF(DPRINTF_EVT_NETWORK, "device_name = %s\n", pEqpConfig->host_config.device_name);    
    #endif
    
    // ethernet MAC address    
    DPRINTF(DPRINTF_EVT_NETWORK,"MAC=%02X:%02X:%02X:%02X:%02X:%02X\n",pDeviceData->mac_addr[0], pDeviceData->mac_addr[1],
    pDeviceData->mac_addr[2], pDeviceData->mac_addr[3], pDeviceData->mac_addr[4], pDeviceData->mac_addr[5]);

#if 0
    // immutable strings
    // company
    strcpy(pEqpConfig->host_config.company, pDeviceData->company);
    //modelname
    strcpy(pEqpConfig->host_config.model_name, pDeviceData->modelname);
    //hwID
    strcpy(pEqpConfig->host_config.hw_id, pDeviceData->hwID);

    // version
    //strcpy(pEqpConfig->host_config.version, pDeviceData->version);
    // built_date
    //strcpy(pEqpConfig->host_config.built_date, pDeviceData->built_date);
#endif

	 return;
}


#if 0
void getConfigData(IpssConfigData *pConfigData)
{
    DPRINTF(DPRINTF_EVT_NETWORK, "getConfigData()\n");

    //initialize structure
    //DeviceConfig myConfig;
    int i,j, netmask_num=0;
    EqpConfig *pEqpConfig = saGetEqpConfigPtr();
    unsigned char *pDataPtr;
    unsigned long network_address, gateway_address, netmask_address;
	unsigned char newip_buffer[50];
	unsigned char newgateway_buffer[50];
	
    //initialize wipss_config / wipss_config_status structur

    //prepare wipss_config data
    pConfigData->config_version = DFT_CONFIG_VERSION;

    pConfigData->dhcp = pEqpConfig->wifi_config.network_mode;
    DPRINTF(DPRINTF_EVT_NETWORK, "pConfigData->dhcp = %d\n",pConfigData->dhcp);

    strcpy(pConfigData->servername, pEqpConfig->host_config.server_name);

    strcpy(pConfigData->serialno, pEqpConfig->host_config.serial_no);

    strcpy(pConfigData->passwd, pEqpConfig->host_config.password);
    //Jeffrey2018.03.21: we lost alignment from here, forced to put data from pos 46
    //Depends on fixed IP or DHCP mode, print out different setting
    pDataPtr = (unsigned char *)pConfigData;
    pDataPtr += 46;
    if(pEqpConfig->wifi_config.network_mode == NM_DHCP_ENABLED)
        network_address = htonl(pEqpConfig->wifi_config.ip);
    else
	{
        network_address = htonl(pEqpConfig->wifi_config.fixed_ip_config);
		printf("new ip:%s\n", inet_ntoa(network_address));
		netmask_address = htonl(pEqpConfig->wifi_config.fixed_netmask_config);
		printf("new netmask:%s\n", inet_ntoa(netmask_address));
		const char *str = ".";
		char *p = strtok(inet_ntoa(netmask_address), str);
		int i;
		for(i=0; i<8; i++)
		{
			if((atoi(p)>>i)& 1)
				netmask_num++;
		}
		while(p = strtok(NULL, str))
		{
			for(i=0; i<8; i++)
			{
				if((atoi(p)>>i)& 1)
					netmask_num++;
			}
		}	
		sprintf(newip_buffer, "sudo ip addr add %s/%d dev eth0", inet_ntoa(network_address), netmask_num);
		if(system(newip_buffer))
			printf("ip system is OK\n");	
		
		gateway_address = htonl(pEqpConfig->wifi_config.fixed_gateway_config);
		printf("new ip gateway:%s\n", inet_ntoa(gateway_address));
		sprintf(newgateway_buffer, "sudo ip route add %s dev eth0", inet_ntoa(gateway_address));
		if(system(newgateway_buffer))
			printf("gateway system is OK\n");
	}
	
    pDataPtr += 4;
    memcpy(pDataPtr, &network_address, 4);
    // IP address
    //pConfigData->ipaddr = htonl(pEqpConfig->wifi_config.ip);
    
    // netmask
    //pConfigData->netmask = htonl(pEqpConfig->wifi_config.netmask);
    if(pEqpConfig->wifi_config.network_mode == NM_DHCP_ENABLED)
        network_address = htonl(pEqpConfig->wifi_config.netmask);
    else
        network_address = htonl(pEqpConfig->wifi_config.fixed_netmask_config);
    pDataPtr += 4;
    memcpy(pDataPtr, &network_address, 4);


    // default gateway
    //pConfigData->gw = htonl(pEqpConfig->wifi_config.gateway);
    if(pEqpConfig->wifi_config.network_mode == NM_DHCP_ENABLED)
        network_address = htonl(pEqpConfig->wifi_config.gateway);
    else
        network_address = htonl(pEqpConfig->wifi_config.fixed_gateway_config);

    pDataPtr += 4;
    memcpy(pDataPtr, &network_address, 4);

    // ethernet MAC address
    //memcpy(pConfigData->mac_addr, pEqpConfig->wifi_config.mac_addr, MAC_ADDRESS_SIZE);
    pDataPtr += 4;

    //pConfigData->mac_addr[0] = pEqpConfig->wifi_config.mac_addr[0];
    //pConfigData->mac_addr[1] = pEqpConfig->wifi_config.mac_addr[1];
    //pConfigData->mac_addr[2] = pEqpConfig->wifi_config.mac_addr[2];
    //pConfigData->mac_addr[3] = pEqpConfig->wifi_config.mac_addr[3];
    //pConfigData->mac_addr[4] = pEqpConfig->wifi_config.mac_addr[4];
    //pConfigData->mac_addr[5] = pEqpConfig->wifi_config.mac_addr[5];
    memcpy(pDataPtr, pEqpConfig->wifi_config.mac_addr, 6);
    pDataPtr += 6;

    // numports(1), console_mode(1)
    *pDataPtr = DFT_NUMPORTS;
    pDataPtr += 1;
    *pDataPtr = 0;
    pDataPtr += 1;

    //pConfigData->numports = DFT_NUMPORTS;
    //pConfigData->console_mode = 0;

    //strcpy(pConfigData->company, pEqpConfig->host_config.company);
    //strcpy(pConfigData->modelname, pEqpConfig->host_config.model_name);
    //strcpy(pConfigData->hwID, pEqpConfig->host_config.hw_id);
    strcpy(pDataPtr, pEqpConfig->host_config.company);
    pDataPtr += 48;
    strcpy(pDataPtr, pEqpConfig->host_config.model_name);
    pDataPtr += 16;
    strcpy(pDataPtr, pEqpConfig->host_config.hw_id);
    pDataPtr += 32; //hw_id + reserved4

    //from here we will have UartParam 

    

    // copy serial port 1 ~ 4
    //memcpy(p_config_data->uart_param, shmMibVcdbPtr->sp_config, sizeof(uart_param)*4);

    for (i = 0; i < DFT_NUMPORTS; i++) {
#if 0
        //DPRINTF(DPRINTF_EVT_NETWORK, "getConfigData():port %d : baudrate = %d\n", p_config_data->uart_param[i].baud);
        //DPRINTF(DPRINTF_EVT_NETWORK, "getConfigData():port %d : databit = %d\n", p_config_data->uart_param[i].databits);
        //DPRINTF(DPRINTF_EVT_NETWORK, "getConfigData():port %d : stopbit = %d\n", p_config_data->uart_param[i].stopbits);
        //DPRINTF(DPRINTF_EVT_NETWORK, "getConfigData():port %d : parity = %d\n", p_config_data->uart_param[i].parity);
        //DPRINTF(DPRINTF_EVT_NETWORK, "getConfigData():port %d : flowctrl = %d\n", p_config_data->uart_param[i].flowctrl);
#endif
        memcpy(&(pConfigData->uart_param[i].sp), &(pEqpConfig->sp_config[i]),sizeof(SerialPortConfig));
        //inter-byte
        pConfigData->uart_param[i].inter_byte = pEqpConfig->inter_byte[i];

#if 0
        DPRINTF(DPRINTF_EVT_NETWORK,
                "getConfigData():port %d : tcp_port = %02X%02X\n\r", i,
                pConfigData->uart_param[i].tcp_port[0],
                pConfigData->uart_param[i].tcp_port[1]);

        DPRINTF(DPRINTF_EVT_NETWORK,
                "getConfigData():port %d : remoteip = %08X\n\r", i,
                pConfigData->uart_param[i].remoteip);

        DPRINTF(DPRINTF_EVT_NETWORK,
                "getConfigData():port %d : hb_port = %02X%02X\n\r", i,
                pConfigData->uart_param[i].hb_port[0],
                pConfigData->uart_param[i].hb_port[1]);

        DPRINTF(DPRINTF_EVT_NETWORK,
                "getConfigData():port %d : c_timeout = %02X%02X\n\r", i,
                pConfigData->uart_param[i].c_timeout[0],
                pConfigData->uart_param[i].c_timeout[1]);

        DPRINTF(DPRINTF_EVT_NETWORK,
                "getConfigData():port %d : force_transmit = %02X%02X\n\r", i,
                pConfigData->uart_param[i].force_transmit[0],
                pConfigData->uart_param[i].force_transmit[1]);
#endif

        for(j = 0; j < UDPIPRANGE; j++)
        {
            //pConfigData->uart_param[i].udp_dest_end[j] = sl_Htonl(g_eqpConfig.sp_config[i].udp_dest_end[j]);
            //pConfigData->uart_param[i].udp_src_begin[j] = sl_Htonl(g_eqpConfig.sp_config[i].udp_src_begin[j]);
            //pConfigData->uart_param[i].udp_src_end[j] = sl_Htonl(g_eqpConfig.sp_config[i].udp_src_end[j]);
            //pConfigData->sp[i].dest_port_num[j] = sl_Htons(g_eqpConfig.sp_config[i].dest_port_num[j]);
            pConfigData->uart_param[i].sp.udp_dest_begin[j] = htonl(pEqpConfig->sp_config[i].udp_dest_begin[j]);
            pConfigData->uart_param[i].sp.udp_dest_end[j] = htonl(pEqpConfig->sp_config[i].udp_dest_end[j]);
            pConfigData->uart_param[i].sp.udp_src_begin[j] = htonl(pEqpConfig->sp_config[i].udp_dest_begin[j]);
            pConfigData->uart_param[i].sp.udp_src_end[j] = htonl(pEqpConfig->sp_config[i].udp_dest_end[j]);
            pConfigData->uart_param[i].sp.dest_port_num[j] = htonl(pEqpConfig->sp_config[i].dest_port_num[j]);
        }
#if 0
        DPRINTF(DPRINTF_EVT_NETWORK,
                "getConfigData(): port %d: max_conn = %d\n\r", i,
                pConfigData->uart_param[i].sp.max_con);
#endif

        for(j = 0; j < UDPIPRANGE; j++)
        {
            //pConfigData->uart_param[i].udp_dest_end[j] = sl_Htonl(g_eqpConfig.sp_config[i].udp_dest_end[j]);
            //pConfigData->uart_param[i].udp_src_begin[j] = sl_Htonl(g_eqpConfig.sp_config[i].udp_src_begin[j]);
            //pConfigData->uart_param[i].udp_src_end[j] = sl_Htonl(g_eqpConfig.sp_config[i].udp_src_end[j]);
            //pConfigData->sp[i].dest_port_num[j] = sl_Htons(g_eqpConfig.sp_config[i].dest_port_num[j]);
            pConfigData->uart_param[i].sp.udp_dest_begin[j] = htonl(pEqpConfig->sp_config[i].udp_dest_begin[j]);
            pConfigData->uart_param[i].sp.udp_dest_end[j] = htonl(pEqpConfig->sp_config[i].udp_dest_end[j]);
            pConfigData->uart_param[i].sp.udp_src_begin[j] = htonl(pEqpConfig->sp_config[i].udp_dest_begin[j]);
            pConfigData->uart_param[i].sp.udp_src_end[j] = htonl(pEqpConfig->sp_config[i].udp_dest_end[j]);
            pConfigData->uart_param[i].sp.dest_port_num[j] = htonl(pEqpConfig->sp_config[i].dest_port_num[j]);
        }
#if 0
        DPRINTF(DPRINTF_EVT_NETWORK,
                "getConfigData(): port %d: max_conn = %d\n\r", i,
                pConfigData->uart_param[i].sp.max_con);
        DPRINTF(DPRINTF_EVT_NETWORK,
                "getConfigData(): port %d: remoteip = %08X\n\r", i,
                pConfigData->uart_param[i].sp.remote_ip);
#endif
    }

#if 0
    DPRINTF(DPRINTF_EVT_NETWORK,
            "getConfigData():port 0 : baudrate = %d, databit = %d\n\r",
            pConfigData->uart_param[0].sp.baudrate,
            pConfigData->uart_param[0].sp.databits);

    DPRINTF(DPRINTF_EVT_NETWORK,
            "getConfigData():port 0 : parity = %d, flowctrl = %d\n\r",
            pConfigData->uart_param[0].sp.parity,
            pConfigData->uart_param[0].sp.flow_ctrl);
#endif
	return;
}

#endif

#if 0
void setConfigData(IpssConfigData *pConfigData)
{
    DPRINTF(DPRINTF_EVT_NETWORK, "setConfigData()\n");

    int i;
    //int j;
    EqpConfig *pEqpConfig = saGetEqpConfigPtr();
    Gatewayconfig *pGatewayconfig = saGetGatewayconfig();
    unsigned char *pDataPtr;
    unsigned long network_address;
	unsigned char fixip_buffer[50];
	unsigned char fixgateway_buffer[50];
    char read_buf[1024];

	bzero(read_buf, sizeof(read_buf));
	
	//FILE *fp_fixip = fopen("fix_ip.txt", "r+");
    FILE *fp_fixip = fopen("fix_ip.sh", "r+");
	setvbuf(fp_fixip, NULL, _IONBF, 0);
	
	pre_networkmode = pEqpConfig->wifi_config.network_mode;
	printf("***pre_networkmode:%d****\n", pre_networkmode);
    pEqpConfig->wifi_config.network_mode = pConfigData->dhcp;
	printf("---later_networkmode:%d---\n", pEqpConfig->wifi_config.network_mode);
	
    strcpy(pEqpConfig->host_config.server_name, pConfigData->servername);
    //strcpy(pEqpConfig->host_config.serial_no, pConfigData->serialno);
    //strcpy(pEqpConfig->host_config.password, pConfigData->passwd);
    // We still have struct 'packed' issue, try copy the payload byte-by-byte
    pDataPtr = &(pConfigData->ipaddr); // Ankor point ipaddr(pos 50)    
    if(pEqpConfig->wifi_config.network_mode == NM_DHCP_DISABLED){
        if(pre_networkmode != pEqpConfig->wifi_config.network_mode)
	    {   
            exchange_flag = 1;  
            pEqpConfig->wifi_config.fixed_ip_config = ntohl(pConfigData->ipaddr);
            //printf("new ip:%s\n", inet_ntoa(pConfigData->ipaddr));
            //sprintf(newip_buffer, "sudo ip addr add %s dev eth0", inet_ntoa(pConfigData->ipaddr));
            //system(newip_buffer);
            //pEqpConfig->wifi_config.fixed_netmask_config = ntohl(pConfigData->netmask);
            //pEqpConfig->wifi_config.fixed_gateway_config = ntohl(pConfigData->gw);
            pDataPtr += 4; // netmask
            memcpy(&network_address, pDataPtr, 4);
            pEqpConfig->wifi_config.fixed_netmask_config = ntohl(network_address);
            pDataPtr += 4; // gateway
            memcpy(&network_address, pDataPtr, 4);
            pEqpConfig->wifi_config.fixed_gateway_config = ntohl(network_address);
            pDataPtr += 4; // to next field, e.g. mac_addr
            DPRINTF(DPRINTF_EVT_NETWORK, "fixed_ip = %s\n", inet_ntoa(ntohl(pEqpConfig->wifi_config.fixed_ip_config)));
            DPRINTF(DPRINTF_EVT_NETWORK, "fixed_netmask = %s\n", inet_ntoa(ntohl(pEqpConfig->wifi_config.fixed_netmask_config)));
            DPRINTF(DPRINTF_EVT_NETWORK, "fixed_gateway = %s\n", inet_ntoa(ntohl(pEqpConfig->wifi_config.fixed_gateway_config)));

            // ofstream ofs;
            // ofs.ipen("../global_conf.json", ios::app);
            // assert(ofs.is_open());

            // Json::Reader reader;
            // Json::Value root;

            // if(!reader.parse(ifs, root, false))
            //     return -1;
            // root["network_mode"].asInt() = pEqpConfig->wifi_config.network_mode;
            // cout << root["network_mode"].asInt() << endl;

            printf("***********json_rdwr*********\n");
            json_rdwr(pGatewayconfig, pEqpConfig);

            system("sudo cp /etc/dhcpcd.conf /etc/dhcpcd.conf.bak");
            system("sudo cp /etc/dhcpcd.conf.bak /etc/dhcpcd.conf");
            fprintf(fp_fixip, "#/bin/bash\n");
            fprintf(fp_fixip, "\techo \"interface eth0\" >> /etc/dhcpcd.conf\n");
            fprintf(fp_fixip, "\techo \"static ip_address=%s\" >> /etc/dhcpcd.conf\n", inet_ntoa(ntohl(pEqpConfig->wifi_config.fixed_ip_config)));
            fprintf(fp_fixip, "\techo \"static domain_name_servers=%s\" >> /etc/dhcpcd.conf\n", inet_ntoa(ntohl(pEqpConfig->wifi_config.fixed_netmask_config)));
            fprintf(fp_fixip, "\techo \"static routers=%s\" >> /etc/dhcpcd.conf\n", inet_ntoa(ntohl(pEqpConfig->wifi_config.fixed_gateway_config)));
            printf("******set fix_ip OK*******\n");
            fflush(fp_fixip);
            fclose(fp_fixip);
            system("./fix_ip.sh");

        }
    }
		
    if(pEqpConfig->wifi_config.network_mode == NM_DHCP_ENABLED){ 
        if(pre_networkmode != pEqpConfig->wifi_config.network_mode)
	    { 
            //printf("fix_ip:%s\n", inet_ntoa(pEqpConfig->wifi_config.fixed_ip_config));
            printf("del fix_ip:%s\n", inet_ntoa(pConfigData->ipaddr));
            sprintf(fixip_buffer, "sudo ip addr del %s dev eth0", inet_ntoa(pConfigData->ipaddr));
            system(fixip_buffer);
            printf("del fix_ip gateway:%s\n", inet_ntoa(pConfigData->gw));
            sprintf(fixgateway_buffer, "sudo ip route del %s dev eth0", inet_ntoa(pConfigData->gw));
            system(fixgateway_buffer);
            system("cp /etc/dhcpcd.conf.bak /etc/dhcpcd.conf");
            exchange_flag = 2;  
        }
        printf("***********json_rdwr*********\n");
        json_rdwr(pGatewayconfig, pEqpConfig);
    }
	
    DPRINTF(DPRINTF_EVT_NETWORK, "dhcp = %d\n", pEqpConfig->wifi_config.network_mode);
    DPRINTF(DPRINTF_EVT_NETWORK, "server_name = %s\n", pEqpConfig->host_config.server_name);    


    // ethernet MAC address
    //	p_config_data->mac_addr[0] = ipcs_config.mac_addr[0];
    //	p_config_data->mac_addr[1] = ipcs_config.mac_addr[1];
    //	p_config_data->mac_addr[2] = ipcs_config.mac_addr[2];
    //	p_config_data->mac_addr[3] = ipcs_config.mac_addr[3];
    //	p_config_data->mac_addr[4] = ipcs_config.mac_addr[4];
    //	p_config_data->mac_addr[5] = ipcs_config.mac_addr[5];

    //	p_config_data->numports = 0;
    //	p_config_data->console_mode = 0;

#if 0
    // immutable strings which could not be changed by VCOMUI
    strcpy(pEqpConfig->host_config.company, pConfigData->company);
    strcpy(pEqpConfig->host_config.model_name, pConfigData->modelname);
    strcpy(pEqpConfig->host_config.hw_id, pConfigData->hwID);
#endif

    for(i = 0; i < DFT_NUMPORTS; i++)
    {

        memcpy(&(pEqpConfig->sp_config[i]), &(pConfigData->uart_param[i].sp), sizeof(SerialPortConfig));
//#if 0
        DPRINTF(DPRINTF_EVT_NETWORK, "setConfigData(2): port %d : max_conn = %d\n", i, pEqpConfig->sp_config[i].max_con);
        //pEqpVcdbIpConfigData->uart_param[i].tcp_port = sl_Ntohs(pConfigData->uart_param[i].tcp_port);
        //DPRINTF(DPRINTF_EVT_NETWORK, "setConfigData(1): port %d: max_con = %d\n", i, pConfigData->uart_param[i].sp.max_con);
#if 0
        if(pConfigData->uart_param[i].sp.max_con > (MAXCONN - 1)){ // MAXCONN connections
        	pConfigData->uart_param[i].sp.max_con = MAXCONN - 1;
        }
        else if(pConfigData->uart_param[i].sp.max_con < 0){
        	pConfigData->uart_param[i].sp.max_con = 0; // 1 connection
        }
        DPRINTF(DPRINTF_EVT_NETWORK, "setConfigData(1): port %d: allowed value = %d", pConfigData->uart_param[i].sp.max_con);
#endif
        //DPRINTF(DPRINTF_EVT_NETWORK, "setConfigData(1): port %d: remote_ip = %08X\n", i, pConfigData->uart_param[i].sp.remote_ip);
        //DPRINTF(DPRINTF_EVT_NETWORK, "setConfigData(1): port %d: tcp_port = %08X\n", i, pConfigData->uart_param[i].sp.tcp_port);
        // For CC3200, sl_Ntohs is redefine to sl_Htons(), we omit this data conversion
        //g_eqpConfig.sp_config[i].tcp_port = sl_Ntohs(pConfigData->uart_param[i].tcp_port);
        //g_eqpConfig.sp_config[i].remote_ip = sl_Ntohl(pConfigData->uart_param[i].remoteip);
        //g_eqpConfig.sp_config[i].hb_port = sl_Ntohl(pConfigData->uart_param[i].hb_port);
        //g_eqpConfig.sp_config[i].con_timeout = sl_Ntohl(pConfigData->uart_param[i].c_timeout);
        //g_eqpConfig.sp_config[i].forced_transmit = sl_Ntohl(pConfigData->uart_param[i].force_transmit);

        DPRINTF(DPRINTF_EVT_NETWORK, "setConfigData(2): port %d : remote_ip = %d\n", i, pEqpConfig->sp_config[i].remote_ip);
        DPRINTF(DPRINTF_EVT_NETWORK, "setConfigData(2): port %d : tcp_port = %d\n", i, pEqpConfig->sp_config[i].tcp_port);

#if 0

        for(j = 0; j < UDPIPRANGE; j++)
        {
            memcpy(g_eqpConfig.sp_config[i], pConfigData->uart_param[i].sp, sizeof(SerialPortConfig));

            //g_eqpConfig.sp_config[i].udp_src_begin[j] = sl_Ntohl(pConfigData->uart_param[i].udpsrc_begin[j]);
            //g_eqpConfig.sp_config[i].udp_src_end[j] = sl_Ntohl(pConfigData->uart_param[i].udpsrc_end[j]);
            //g_eqpConfig.sp_config[i].udp_dest_begin[j] = sl_Ntohl(pConfigData->uart_param[i].udpdest_begin[j]);
            //g_eqpConfig.sp_config[i].udp_dest_begin[j] = sl_Ntohl(pConfigData->uart_param[i].udpdest_end[j]);
            //g_eqpConfig.sp_config[i].dest_port_num[j] = sl_Ntohl(pConfigData->uart_param[i].destportnum[j]);
        }

#endif
    }

    // copy serial port 1 ~ 4
    //memcpy(&(shmMibVcdbPtr->sp_config), &(p_config_data->uart_param), sizeof(uart_param)*4);


#if 0
    DPRINTF(DPRINTF_EVT_NETWORK, "setConfigData():port 0 : baudrate = %d, databits = %d\n",
    		pEqpConfig->sp_config[0].baudrate, pEqpConfig->sp_config[0].databits);

    DPRINTF(DPRINTF_EVT_NETWORK, "setConfigData():port 0 : parity = %d, flowctrl = %d\n",
    		pEqpConfig->sp_config[0].parity, pEqpConfig->sp_config[0].flow_ctrl);
#endif
	 return;
}

#endif
