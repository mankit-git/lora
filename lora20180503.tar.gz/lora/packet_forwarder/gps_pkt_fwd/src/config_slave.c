#include "common.h"

int main(void)
{
	key_t key = ftok(PROJ_PATH, PROJ_ID);
	int msgid = msgget(key, IPC_CREAT|0666);

	struct msgbuffer msg;
	while(1)
	{
		bzero(&msg, sizeof(msg));

		//send msg.mtext to msgid
		//0:blocking send.if msg queue is full, waiting here.
		msgrcv(msgid, &msg, MSGSIZE, J2R, 0);

		printf("from config_slave: %s\n", msg.mtext);
		int num = strncmp(msg.mtext, "fix_ip mode", 11);
		if(num == 0)
			system("sudo dhcpcd -k eth0");
		else
			system("sudo dhcpcd -n eth0");
	}

	return 0;
}
