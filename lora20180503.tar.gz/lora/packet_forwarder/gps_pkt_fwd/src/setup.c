#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
//#include <sys/types.h>
//#include <sys/ioctl.h>
//#include <net/if.h>
//#include <syslog.h>

// for setsockopt(), getsockopt()
#include <sys/types.h>
#include <sys/socket.h>
//ntohl()
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>

//#include <netdb.h>
//#include <netinet/in.h>

#include <time.h> // for time(), localtime()

#include "command_define.h"
#include "g_config_data.h"
#include "cmd_process.h"
#include "debug_setting.h"


//*****************************************************************************
//                 GLOBAL VARIABLES -- Start
//*****************************************************************************


//*****************************************************************************
//                 GLOBAL VARIABLES -- End
//*****************************************************************************



//****************************************************************************
//                      LOCAL FUNCTION PROTOTYPES
//****************************************************************************

SearchFormat search_format;

void get_current_datetime(char *date_n_time)
{
	time_t curr;
  	struct tm * tTM;
	//struct tm *tblock;
  
  	tzset();
  
  	//time get the elapsed time
  	time(&curr);
  	//DPRINTF(DPRINTF_EVT_NETWORK, "current time is %ld seconds\n", curr);
  
  	//tblock = localtime(&curr);
  	//DPRINTF(DPRINTF_EVT_NETWORK, "Local time is: %s\n", asctime(tblock));
  
  	//use localtime() to convert time_t format
  	tTM = localtime(&curr);
	// example format:
  	sprintf(date_n_time, "%4d%02d%02d %02d:%02d:%02d", tTM->tm_year + 1900, tTM->tm_mon + 1, tTM->tm_mday, 
  	tTM->tm_hour, tTM->tm_min, tTM->tm_sec);
	
	DPRINTF(DPRINTF_EVT_NETWORK, "Current DateTime(%d) = \"%s\"\n", strlen(date_n_time), date_n_time);
	
	return;
}
  

void process_client_event(int sockfd)
{
	struct sockaddr_in clntaddr;
    char message[1200], buffer[1200];
   
    //socklen_t len;
	socklen_t addr_len = sizeof(struct sockaddr_in);

    int readbytes;
	unsigned char *p_config;
	int count, i;
	DeviceConfigData device_config_data;
	SearchCommand *pSearchCommand;

	EqpConfig *pEqpConfig = saGetEqpConfigPtr();

	bzero(message, sizeof(message));
	//readbytes = recvfrom(sockfd, message, sizeof(message), 0, (struct sockaddr *)&clntaddr, &len);
	readbytes = recvfrom(sockfd, (void *) message, sizeof(message), 0, (struct sockaddr *)&clntaddr, (socklen_t *)&addr_len);

	memcpy( buffer, message, readbytes );

	DPRINTF(DPRINTF_EVT_NETWORK, "process_client_event():Receive from %s, port %d\n", inet_ntoa(clntaddr.sin_addr), ntohs(clntaddr.sin_port));
		
	switch(readbytes)
	{
		case SEARCH_COMMNAD_LEN:
			// ESP Manager Search Command
			if(memcmp(buffer, Command_Token, strlen(Command_Token)) == 0)
			{
				pSearchCommand = (SearchCommand *)buffer;
				DPRINTF(DPRINTF_EVT_NETWORK, "service_ip = %08X, service_port = %d, service_type = %d\n", ntohl(pSearchCommand->service_info.service_ip), \
				  ntohs(pSearchCommand->service_info.service_port), ntohs(pSearchCommand->service_info.service_type));
					//ConfigMaster's search command
					//initialize structure
					memset(&search_format, 0, sizeof(SearchFormat));					

					// fill response header
					search_format.delimiter.flag = Command_Delimiter;		
					//HWaddr:08:00:27:53:e6:7e 
					search_format.delimiter.mac_addr[0] = pEqpConfig->network_config.mac_addr[0];
					search_format.delimiter.mac_addr[1] = pEqpConfig->network_config.mac_addr[1];
					search_format.delimiter.mac_addr[2] = pEqpConfig->network_config.mac_addr[2];
					search_format.delimiter.mac_addr[3] = pEqpConfig->network_config.mac_addr[3];
					search_format.delimiter.mac_addr[4] = pEqpConfig->network_config.mac_addr[4];
					search_format.delimiter.mac_addr[5] = pEqpConfig->network_config.mac_addr[5];

					search_format.delimiter.seq_no = 0;
					
					//memset(&device_config_data, 0, sizeof(DeviceConfigData));

					getDeviceConfig((DeviceConfigData *)search_format.payload);

					//memcpy(search_format.payload, &device_config_data, sizeof(DeviceConfigData));

					
					p_config = (unsigned char *)&search_format.payload;
		
					//parepare payload 1
					//memcpy(search_format.payload, p_config, SEARCH_PAYLOAD1_SIZE);					

					//prepare checksum of search packets
					search_format.checksum = 0;

					p_config = (unsigned char *)&search_format.payload;		
					for(i = 0; i <  sizeof(DeviceConfigData); i++)
					{			
						search_format.checksum += *(p_config + i);
					}				

					DPRINTF(DPRINTF_EVT_NETWORK, "checksum = %02X\n", search_format.checksum);					

			        // payload 1
					count = sendto(sockfd, &search_format, sizeof(SearchFormat),
			        		0, (struct sockaddr *)&clntaddr, addr_len);
					DPRINTF(DPRINTF_EVT_NETWORK, "sendto() buffer size = %d(actual = %d)\n", sizeof(SearchFormat), count);

					if(count == -1) {
						DPRINTF(DPRINTF_EVT_NETWORK,  "errno = %d\n", errno);
						//perror("EI(NVAL(22)");
					}
					
					//DPRINTF(DPRINTF_EVT_NETWORK, "EBADF(%d)/EFAULT(%d)/WNOTSOCK(%d)/EINTR(%d)/EAGAIN(%d)/ENOBUFS(%d)/EINVAL(%d)\n", 
					//    EBADF, EFAULT,WNOTSOCK, EINTR, EAGAIN, ENOBUFS, EINVAL);
            
		       	 }
				break;
			case MESSAGE_COMMAND_LEN:
				{
					CmdMsg *p_cmd_msg;
					p_cmd_msg = (CmdMsg *)buffer;

					DPRINTF(DPRINTF_EVT_NETWORK, "MESSAGE_COMMAND_LEN(%d)\n", readbytes);

					DPRINTF(DPRINTF_EVT_NETWORK, "service_port = %08X, service_port = %d, service_type = %d\n", ntohl(p_cmd_msg->service_info.service_ip), \
					  ntohs(p_cmd_msg->service_info.service_port), ntohs(p_cmd_msg->service_info.service_type));

					DPRINTF(DPRINTF_EVT_NETWORK, "REQ:mac_addr[0] = %02X, mac_addr[1] = %02X, mac_addr[2] = %02X\n", 
						p_cmd_msg->mac_addr[0], p_cmd_msg->mac_addr[1], p_cmd_msg->mac_addr[2]);

					DPRINTF(DPRINTF_EVT_NETWORK, "REQ:mac_addr[3] = %02X, mac_addr[4] = %02X, mac_addr[5] = %02X\n", 
						p_cmd_msg->mac_addr[3], p_cmd_msg->mac_addr[4], p_cmd_msg->mac_addr[5]);
					
					//check if mac address is mine
					//HWaddr:08:00:27:53:e6:7e
					if((p_cmd_msg->mac_addr[0] == pEqpConfig->network_config.mac_addr[0]) && (p_cmd_msg->mac_addr[1] == pEqpConfig->network_config.mac_addr[1]) &&
						(p_cmd_msg->mac_addr[2] == pEqpConfig->network_config.mac_addr[2]) && (p_cmd_msg->mac_addr[3] == pEqpConfig->network_config.mac_addr[3]) &&
						(p_cmd_msg->mac_addr[4] == pEqpConfig->network_config.mac_addr[4]) && (p_cmd_msg->mac_addr[5] == pEqpConfig->network_config.mac_addr[5]) 
					)
					{
				    		if(strcmp(p_cmd_msg->command, Command_Reboot_Token) == 0)
				    		{
				         		DPRINTF(DPRINTF_EVT_NETWORK, "Reboot Command Received.\n");
						   		// TODO: do a self reboot(actually, reload JSON config file, relaunch LoRa packet forwarder)
				    		}
							if(strcmp(p_cmd_msg->command, Command_TimeSync_Token) == 0)
				    		{
				         		DPRINTF(DPRINTF_EVT_NETWORK, "TimeSync Command Received.\n");
						   		// TODO: Check ConfigMaster's Param format string if valid or not
								// Synchronize ConfigMaster's clock as my local clock								
								sprintf(message, "sudo date -s \"%s\"", p_cmd_msg->param);
								DPRINTF(DPRINTF_EVT_NETWORK, "[TimeSync]%s\n", message);
								system(message);
				    		}
				    		if(strcmp(p_cmd_msg->command, Command_ClearBuf_Token) == 0)
				    		{
				        		DPRINTF(DPRINTF_EVT_NETWORK, "ClearBuf Command Received.\n");
						  		//TODO: synchronize RAM config to my flash
								
								//Send an Ack Message to ConfigMaster
						  		ServerAckMsg ack_msg;
						  		memset(&ack_msg, 0, sizeof(ServerAckMsg));
						  		// delimiter
						  		ack_msg.flag = Command_Delimiter;
						  		// mac address
								//HWaddr:08:00:27:53:e6:7e
						  		ack_msg.mac_addr[0] = pEqpConfig->network_config.mac_addr[0];
						  		ack_msg.mac_addr[1] = pEqpConfig->network_config.mac_addr[1];
						  		ack_msg.mac_addr[2] = pEqpConfig->network_config.mac_addr[2];
						  		ack_msg.mac_addr[3] = pEqpConfig->network_config.mac_addr[3];
						  		ack_msg.mac_addr[4] = pEqpConfig->network_config.mac_addr[4];
						  		ack_msg.mac_addr[5] = pEqpConfig->network_config.mac_addr[5];
						  		// sequence number
						  		ack_msg.seq = 0;
						  		// response message
						  		strcpy(ack_msg.msg, Server_Ack_Token);
							
								count = sendto(sockfd, &ack_msg, sizeof(ServerAckMsg),
			        				0, (struct sockaddr *)&clntaddr, sizeof(struct sockaddr) );
								DPRINTF(DPRINTF_EVT_NETWORK, "server_ack_msg size = %d(actual = %d)\n", sizeof(ServerAckMsg), count);
						  
				 	  	 }
						else
							DPRINTF(DPRINTF_EVT_NETWORK, "%s, len = %d\n", p_cmd_msg->command, strlen(p_cmd_msg->command));
					}
				}
				
				break;
			case UPDATE_COMMAND_LEN:
				{
					UpdateFormat *p_update_data;
					//unsigned char *p_update_payload;

					DPRINTF(DPRINTF_EVT_NETWORK, "UPDATE_COMMAND1_LEN(%d)\n", readbytes);
					p_update_data = (UpdateFormat *)buffer;

					DPRINTF(DPRINTF_EVT_NETWORK, "REQ: mac_addr[0] = %02X, mac_addr[1] = %02X, mac_addr[2] = %02X\n", 
						p_update_data->header.mac_addr[0], p_update_data->header.mac_addr[1], p_update_data->header.mac_addr[2]);

					DPRINTF(DPRINTF_EVT_NETWORK, "REQ: mac_addr[3] = %02X, mac_addr[4] = %02X, mac_addr[5] = %02X\n", 
						p_update_data->header.mac_addr[3], p_update_data->header.mac_addr[4], p_update_data->header.mac_addr[5]);
					
					//HWaddr:08:00:27:53:e6:7e
					if((p_update_data->header.mac_addr[0] == pEqpConfig->network_config.mac_addr[0]) && (p_update_data->header.mac_addr[1] == pEqpConfig->network_config.mac_addr[1]) &&
					(p_update_data->header.mac_addr[2] == pEqpConfig->network_config.mac_addr[2]) && (p_update_data->header.mac_addr[3] == pEqpConfig->network_config.mac_addr[3]) &&
					(p_update_data->header.mac_addr[4] == pEqpConfig->network_config.mac_addr[4]) && (p_update_data->header.mac_addr[5] == pEqpConfig->network_config.mac_addr[5]) 
					)
					{
						DPRINTF(DPRINTF_EVT_NETWORK, "UPDATE_PAYLOAD_SIZE(%d)\n", UPDATE_PAYLOAD_SIZE);
						//p_update_payload = p_update_data->payload;
						//memcpy(&wipss_update_config, p_update_payload, UPDATE_PAYLOAD1_SIZE);
						//update_segment1_available = 1;
						memcpy(&device_config_data, (p_update_data->payload), UPDATE_PAYLOAD_SIZE);
						setDeviceConfig(&device_config_data);
						DPRINTF(DPRINTF_EVT_NETWORK, "upate OK\n");
					}
				}
				break;			
				
			default:				
				DPRINTF(DPRINTF_EVT_NETWORK, "Unknown command, len = %d\n", readbytes);
				break;
		}

	return;
}


