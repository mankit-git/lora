#include   <stdio.h>   
#include   <sys/ioctl.h>   
#include   <sys/socket.h>   
#include   <netinet/in.h>   
#include   <net/if.h>   
#include   <string.h> 

//#include "g_config_data.h"
//#include "debug_setting.h"


// global variable declaration
// ----------------------------------------------------------------


// ----------------------------------------------------------------

//------------------------------------------------------------------------

int NetMACAddressGet(unsigned char *nic_mac)
{
	struct   ifreq  s_ifreq;   
    int   sock;
    int i;
    
    if((sock=socket(AF_INET,SOCK_STREAM,0)) <0)   
    {   
        perror( "socket ");   
        return   2;   
    }   
    
    //strcpy(s_ifreq.ifr_name, DFT_NIC_NAME);   
    strcpy(s_ifreq.ifr_name, "eth0");   
    
    if(ioctl(sock,SIOCGIFHWADDR,&s_ifreq) <0)   
    {   
        perror( "ioctl ");   
        return   3;   
    }

    for(i = 0; i < 6; i++){
        nic_mac[i] = s_ifreq.ifr_hwaddr.sa_data[i];
    }
/*
    DPRINTF(DPRINTF_EVT_NETWORK, "%02x:%02x:%02x:%02x:%02x:%02x\n ",   
            (unsigned   char)ifreq.ifr_hwaddr.sa_data[0],   
            (unsigned   char)ifreq.ifr_hwaddr.sa_data[1],   
            (unsigned   char)ifreq.ifr_hwaddr.sa_data[2],   
            (unsigned   char)ifreq.ifr_hwaddr.sa_data[3],   
            (unsigned   char)ifreq.ifr_hwaddr.sa_data[4],   
            (unsigned   char)ifreq.ifr_hwaddr.sa_data[5]);
            */
    return 0;
}
