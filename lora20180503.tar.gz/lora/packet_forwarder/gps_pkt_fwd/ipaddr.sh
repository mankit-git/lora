#!/bin/bash
ifconfig eth0|grep Mask: > ipaddr_1
sed -n -f sedlist ipaddr_1 > ipaddr_2
sed -n '2p' ipaddr_2 > ipaddr_ip
sed -n '6p' ipaddr_2 > ipaddr_subnet
