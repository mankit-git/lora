#!/bin/bash

dir=`cd $(dirname "$0") & pwd`
cp -f ${dir}/pktfwd.service /lib/systemd/system/pktfwd.service

systemctl daemon-reload
systemctl enable pktfwd
systemctl restart pktfwd
