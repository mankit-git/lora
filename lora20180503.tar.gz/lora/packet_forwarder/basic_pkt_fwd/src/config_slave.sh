#!bin/sh
#description:service
. /etc/init.d/

#the service name is config_slave
SNAME=config_slave

PROG=/usr/bin/$SNAME

#start function
start(){
	#check the daemon status first
	if [ -f /var/lock/subsys/$SNAME ]
	then
		echo "$SNAME is already started!"
		exit 0;
	else
		action "Starting $SNAME ..." $PROG
		[ $? -eq 0 ] && rouch /var/lock/subsys/$SNAME
		exit 0;
	fi
}

#stop function
stop(){
	echo "Stoping $SNAME ..."
	killproc $SNAME
	rm -rf /var/lock/subsys/$SNAME
}


case "$1" in
start)
	start
	;;
stop)
	stop
	;;
restart|reload)
	stop
	start
	;;
status)
	status $name
	;;
*)
	echo $"Usage: $0 {start|stop|restart|status}"
	exit 1
esac


