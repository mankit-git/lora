#include <sys/socket.h> // for inet_aton(), inet_addr(), inet_network() 
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h> // 

#include <stdio.h>
#include <stdlib.h> // for system()
#include <string.h>

//#include <net/if.h>
//#include <sys/ioctl.h>
//#include <ifaddrs.h>

//#include <errno.h>
//#include   <stdio.h>   
//#include   <sys/ioctl.h>   
//#include   <sys/socket.h>   
//#include   <netinet/in.h>   
//#include   <net/if.h>   
//#include   <string.h> 

#include "g_config_data.h"
#include "debug_setting.h"


// global variable declaration
// ----------------------------------------------------------------

EqpConfig g_eqpConfig;


// ----------------------------------------------------------------
extern int inet_aton(const char *string, struct in_addr *addr);
extern int NetMACAddressGet(unsigned char *nic_mac);
//------------------------------------------------------------------------


// from sync_access.cpp
// Purpose: centralized config data access
EqpConfig* saGetEqpConfigPtr(void)
{
	return &g_eqpConfig;
}

void read_str(char  *des, char  *src)
{
	sprintf(des, "%s", src);   
}

unsigned long getipaddress(void)
{
	//char *test_p;
    FILE *stream = NULL;
    int i;
    struct in_addr inp;
    char    *delim = ":";
    char    *delim2 = " ";
    char    *p = NULL;
    unsigned long ip = 0;
    char    buffer[256];

    //chdir(DFT_WORKING_DIR);
    //chmod rwx(421=7), sudo chmod o+w readme.txt: user/group/other
    system("chmod +x ipaddr.sh");
    system("./ipaddr.sh");
    for(i=0;i<255;i++) buffer[i] = '\0';

    //sprintf( buffer , "I am %s." , cuserid() );
    //buffer[255] = '\0';
    //syslog(LOG_SYSLOG | LOG_NOTICE, buffer);

    stream = fopen("./ipaddr_1","r");
    fread( buffer , sizeof(char) , 255 , stream );
    buffer[255] = '\0';

    p = strtok(buffer,delim);
    //syslog(LOG_SYSLOG | LOG_NOTICE, "strtok 1 = ");
    //syslog(LOG_SYSLOG | LOG_NOTICE, p);
    if( p !=  NULL){
        p = strtok(NULL,delim2);

        //syslog(LOG_SYSLOG | LOG_NOTICE, "strtok 2 = ");
        //syslog(LOG_SYSLOG | LOG_NOTICE, p);

        sprintf(buffer, "%s",p);
        //    buffer[255] = '\0';websWrite(wp, buffer);
    }
    printf("****p:%s*****\n", p);
    // printf("****buffer:%s*****\n", buffer);

    buffer[255] = '\0';

    fclose(stream);

    //Jeffrey2018.03.21: magic string '(null)'
    if(p == NULL){
        ip = 0;
		printf("p=NULL\n");
	}
    else {
        //DPRINTF(DPRINTF_EVT_NETWORK, "getdefaultgateway=%s\n", buffer);
        inet_aton(buffer, &inp);
        //htonl(), ntohl()
        ip = ntohl(inp.s_addr);
    }
   // DPRINTF(DPRINTF_EVT_NETWORK, "IP = 0x%08X\n",ip);

    return ip;
}

void getipaddr(unsigned long *ip)
{
    //char *test_p;
    FILE *stream = NULL;
    int i;
    struct in_addr inp;
    char    *delim = ":";
    char    *delim2 = " ";
    char    *p;
    char    buffer[256];
    char ascii_string[20];
    char null_string[] = "(null)";

    //chdir(DFT_WORKING_DIR);
    //chmod rwx(421=7), sudo chmod o+w readme.txt: user/group/other
    system("chmod +x ipaddr.sh");
    system("./ipaddr.sh");
    for(i=0;i<255;i++) buffer[i] = '\0';

    //sprintf( buffer , "I am %s." , cuserid() );
    //buffer[255] = '\0';
    //syslog(LOG_SYSLOG | LOG_NOTICE, buffer);

    stream = fopen("./ipaddr_1","r");
    fread( buffer , sizeof(char) , 255 , stream );
    buffer[255] = '\0';

    p = strtok(buffer,delim);
    //syslog(LOG_SYSLOG | LOG_NOTICE, "strtok 1 = ");
    //syslog(LOG_SYSLOG | LOG_NOTICE, p);
    if( p !=  NULL){
        p = strtok(NULL,delim2);

        //syslog(LOG_SYSLOG | LOG_NOTICE, "strtok 2 = ");
        //syslog(LOG_SYSLOG | LOG_NOTICE, p);

        sprintf(buffer, "%s",p);
        //    buffer[255] = '\0';websWrite(wp, buffer);
    }

    buffer[255] = '\0';

    fclose(stream);

    //Jeffrey2018.03.21: magic string '(null)'
    sprintf(ascii_string, "%s", buffer);    
    if(memcmp(ascii_string, null_string, 6) == 0)
        *ip = 0;
    else {
        //DPRINTF(DPRINTF_EVT_NETWORK, "getdefaultgateway=%s\n", buffer);
        inet_aton(buffer, &inp);
        //htonl(), ntohl()
        *ip = ntohl(inp.s_addr);
    }
    //DPRINTF(DPRINTF_EVT_NETWORK, "IP = 0x%08X\n",*ip);

    return;
}

void getmask(unsigned long *subnet_mask)
{
    //char *test_p;
    FILE *stream;
    int i;
    struct in_addr inp;
    char    *delim = ":";
    char    *delim2 = " ";
    char    *p;
    char    buffer[256];
    char ascii_string[20];
    char null_string[] = "(null)";


    //chdir("/opt/goahead/LINUX/");
    //system("chmod +x ipaddr.sh");
    //system("./ipaddr.sh");
	//system("../ip_setup/ipaddr.sh");
	//chdir(DFT_WORKING_DIR);
	system("./ipaddr.sh");
    for(i=0;i<255;i++) buffer[i] = '\0';
    stream = fopen("./ipaddr_1","r");
    fread( buffer , sizeof(char) , 255 , stream );


    buffer[255] = '\0';

    p = strtok(buffer,delim);
    p = strtok(NULL,delim);
    p = strtok(NULL,delim);
    p = strtok(NULL,delim2);
    sprintf(buffer, "%s",p);
    buffer[255] = '\0';

    fclose(stream);	
    //DPRINTF(DPRINTF_EVT_NETWORK, "subnet mask: %s\n", buffer);

    //Jeffrey2018.03.21: magic string '(null)'
    sprintf(ascii_string, "%s", buffer);    
    if(memcmp(ascii_string, null_string, 6) == 0)
        *subnet_mask = 0;
    else {
        //DPRINTF(DPRINTF_EVT_NETWORK, "getdefaultgateway=%s\n", buffer);
        inet_aton(buffer, &inp);
        //htonl(), ntohl()
        *subnet_mask = ntohl(inp.s_addr);
    }
    //DPRINTF(DPRINTF_EVT_NETWORK, "subnet = 0x%08X\n",*subnet_mask);


    return;
}


void getdefaultgateway(unsigned long *gateway)
{
    //char *test_p;
    FILE *stream;
    int i;
    char    *delim = " ";
    char    *p;
    char    buffer[256];
    struct in_addr inp;    
    char ascii_string[20];
    char null_string[] = "(null)";

    //chdir(DFT_WORKING_DIR);
    system("chmod +x gateway.sh");
    system("./gateway.sh");
    for(i=0;i<255;i++) buffer[i] = '\0';
    stream = fopen("./gateway_1","r");
    fread( buffer , sizeof(char) , 255 , stream );
    buffer[255] = '\0';

    p = strtok(buffer,delim);
    p = strtok(NULL,delim);
    
    if(p == 0)
        strcpy(buffer, IP_ADDRESS_NOT_AVAILABLE);
    else
        sprintf(buffer, "%s",p);
        
    //buffer[255] = '\0';
    fclose(stream);

    //Jeffrey2018.03.21: magic string '(null)'
    sprintf(ascii_string, "%s", buffer);    
    if(memcmp(ascii_string, null_string, 6) == 0)
        *gateway = 0;
    else {
        //DPRINTF(DPRINTF_EVT_NETWORK, "getdefaultgateway=%s\n", buffer);
        inet_aton(buffer, &inp);
        //htonl(), ntohl()
        *gateway = ntohl(inp.s_addr);
    }

    //DPRINTF(DPRINTF_EVT_NETWORK, "subnet = 0x%08X\n",*gateway);

    return;

}

void get_Primary_dns(NetworkMode mode, unsigned long *pri_dns)
{
    //char *test_p;
    FILE *stream;
    int i;
    char    *delim = " ";
    //char    *delim2 = "n";
    //char    *delim3 = "=,";
    char    *p;
    char    buffer[256];
    struct in_addr inp;
    char ascii_string[20];
    char null_string[] = "(null)";   
   
   //if(strcmp(buffer,NETWORK_MODE_STATIC) == 0 ){
#if 0
   if(mode == NM_DHCP_DISABLED){
   //trace("get_Primary_dns(): STATIC mode\n");
        // STATIC mode    
    chdir(DFT_WORKING_DIR);
    system("chmod +x dns.sh");
    system("./dns.sh");    
    memset(buffer, 0, 256);
    stream = fopen("./dns_1","r");
    fread( buffer , sizeof(char) , 255 , stream );
    buffer[255] = '\0';
    p = strtok(buffer,delim);
    //trace("get_Primary_dns(): p1 = %s\n", p);
    p = strtok(NULL,delim);
    //trace("get_Primary_dns(): p2 = %s\n", p);
    sprintf(buffer, "%s",p);
    // note : trim the trailing '192.168.123.1\rnameserver'
    for(i = 0 ; i < 256 ; i++){
        if(buffer[i] == ' ' || buffer[i] == '\r' || buffer[i] == '\n'){
            buffer[i] = 0;
            break;
        }
    }
    buffer[255] = 0;    
    fclose(stream);
    }
    else {
    //trace("get_Primary_dns(): DHCP mode\n");
    	// DHCP mode    	        
    	chdir(DFT_WORKING_DIR);
    	
        system("chmod +x dns_dhcp.sh");
        system("./dns_dhcp.sh");
        
        memset(buffer, 0, 256);
        stream = fopen("./dns_dhcp","r");
        fread( buffer , sizeof(char) , 255 , stream );
        buffer[255] = '\0';
        p = strtok(buffer,delim3);
        p = strtok(NULL, delim3);
        if(p == 0)
            strcpy(buffer, IP_ADDRESS_NOT_AVAILABLE);
        else
            sprintf(buffer, "%s",p);
            
        fclose(stream);
        //trace("DNS = %s", buffer);
    }
    //trace("get_Primary_dns(): %s\n", buffer);
#else
    //chdir(DFT_WORKING_DIR);
    system("chmod +x dns.sh");
    system("./dns.sh");    
    memset(buffer, 0, 256);
    stream = fopen("./dns_1","r");
    fread( buffer , sizeof(char) , 255 , stream );
    buffer[255] = '\0';
    p = strtok(buffer,delim);
    //trace("get_Primary_dns(): p1 = %s\n", p);
    p = strtok(NULL,delim);
    //trace("get_Primary_dns(): p2 = %s\n", p);
    sprintf(buffer, "%s",p);
    // note : trim the trailing '192.168.123.1\rnameserver'
    for(i = 0 ; i < 256 ; i++){
        if(buffer[i] == ' ' || buffer[i] == '\r' || buffer[i] == '\n'){
            buffer[i] = 0;
            break;
        }
    }
    buffer[255] = 0;    
    fclose(stream);
#endif
    //DPRINTF(DPRINTF_EVT_NETWORK, "get_Primary_dns=%s\n", buffer);

    //Jeffrey2018.03.21: magic string '(null)'
    sprintf(ascii_string, "%s", buffer);    
    if(memcmp(ascii_string, null_string, 6) == 0)
        *pri_dns = 0;
    else {
        inet_aton(buffer, &inp);
        //htonl(), ntohl()
        *pri_dns = ntohl(inp.s_addr);
    }
    DPRINTF(DPRINTF_EVT_NETWORK, "pri_dns = 0x%08X\n",*pri_dns);
    
    return;

}

void get_Secondary_dns(NetworkMode mode, unsigned long *sec_dns)
{
    //char *test_p;
    FILE *stream;
    //int i;
    char    *delim = " ";
    //char    *delim2 = "n";
    //char    *delim3 = "=,";
    char    *p;
    char    buffer[256];
    struct in_addr inp;
    //char ascii_string[20];
    //char null_string[] = "(null)";
    //int k;
    

    //Jeffrey20071022: get IP mode, if we are in DHCP mode, retrieve DNS1 from 
   // file "/etc/dhcpc/dhcpcd-ixp0.info"  
   //read_str(buffer, shmMibVcdbPtr->ipconfig.ip_mode);
   
   //trace("get_Secondary_dns(): buffer = %s\n", buffer);

#if 0   
   //if(strcmp(buffer,NETWORK_MODE_STATIC) == 0 ){
    if(mode == NM_DHCP_DISABLED){
    //trace("get_Secondary_dns(): STATIC mode\n");
    chdir(DFT_WORKING_DIR);
    system("chmod +x dns.sh");
    system("./dns.sh");
    memset(buffer, 0, 256);
    stream = fopen("./dns_1","r");
    fread( buffer , sizeof(char) , 255 , stream );
    buffer[255] = '\0';
    p = strtok(buffer,delim);
    //trace("get_Secondary_dns(): p1 = %s\n", p);
    p = strtok(NULL,delim);
    //trace("get_Secondary_dns(): p2 = %s\n", p);
    p = strtok(NULL,delim);
    //trace("get_Secondary_dns(): p3 = %s\n", p);
    sprintf(buffer, "%s",p);
    buffer[255] = '\0';
    fclose(stream);
    }
    else {        	        
    	// DHCP mode    	        
    	//trace("get_Secondary_dns(): DHCP mode\n");
    	chdir(DFT_WORKING_DIR);    	
    
        system("chmod +x dns_dhcp.sh");
        system("./dns_dhcp.sh");
      
        memset(buffer, 0, 256);
        stream = fopen("./dns_dhcp","r");
        fread( buffer , sizeof(char) , 255 , stream );
        buffer[255] = '\0';
        p = strtok(buffer,delim3);
        p = strtok(NULL, delim3);
        p = strtok(NULL, delim3);
        if(p == 0)
            strcpy(buffer, IP_ADDRESS_NOT_AVAILABLE);
        else
            sprintf(buffer, "%s",p);
            
        fclose(stream);
        //trace("DNS2 = %s\n", buffer);
    }
    //trace("get_Secondary_dns(): %s\n", buffer);
#else
    //chdir(DFT_WORKING_DIR);
    system("chmod +x dns.sh");
    system("./dns.sh");
    memset(buffer, 0, 256);
    stream = fopen("./dns_1","r");
    fread( buffer , sizeof(char) , 255 , stream );
    buffer[255] = '\0';
    p = strtok(buffer,delim);
    //trace("get_Secondary_dns(): p1 = %s\n", p);
    //DPRINTF(DPRINTF_EVT_NETWORK, "p1 = %s\n", p);
    p = strtok(NULL,delim);
    //trace("get_Secondary_dns(): p2 = %s\n", p);
    //DPRINTF(DPRINTF_EVT_NETWORK, "p2 = %s\n", p);
    p = strtok(NULL,delim);
    //trace("get_Secondary_dns(): p3 = %s\n", p);
    //DPRINTF(DPRINTF_EVT_NETWORK, "p3 = %s\n", p);
    if(p == '\0'){
        *sec_dns = 0;
        fclose(stream);
        return;
    }
    else {
        sprintf(buffer, "%s",p);
        buffer[255] = '\0';        
    }
    fclose(stream);
#endif

    //DPRINTF(DPRINTF_EVT_NETWORK, "get_Secondary_dns(): %s\n",buffer);

    //Jeffrey2018.03.21: magic string '(null)'
    inet_aton(buffer, &inp);
    //htonl(), ntohl()
    *sec_dns = ntohl(inp.s_addr);    
    DPRINTF(DPRINTF_EVT_NETWORK, "sec_dns = 0x%08X\n",*sec_dns);

    return;
}

#if 0
int NetMACAddressGet(unsigned char *nic_mac)
{
	struct   ifreq  s_ifreq;   
    int   sock;
    int i;
    
    if((sock=socket(AF_INET,SOCK_STREAM,0)) <0)   
    {   
        perror( "socket ");   
        return   2;   
    }   
    strcpy(s_ifreq.ifr_name, DFT_NIC_NAME);   
    if(ioctl(sock,SIOCGIFHWADDR,&s_ifreq) <0)   
    {   
        perror( "ioctl ");   
        return   3;   
    }

    for(i = 0; i < 6; i++){
        nic_mac[i] = s_ifreq.ifr_hwaddr.sa_data[i];
    }
    
    /*
    DPRINTF(DPRINTF_EVT_NETWORK, "%02x:%02x:%02x:%02x:%02x:%02x\n ",   
            (unsigned   char)ifreq.ifr_hwaddr.sa_data[0],   
            (unsigned   char)ifreq.ifr_hwaddr.sa_data[1],   
            (unsigned   char)ifreq.ifr_hwaddr.sa_data[2],   
            (unsigned   char)ifreq.ifr_hwaddr.sa_data[3],   
            (unsigned   char)ifreq.ifr_hwaddr.sa_data[4],   
            (unsigned   char)ifreq.ifr_hwaddr.sa_data[5]);
    */
    return 0;
}

#endif

void InitNetworkConfig()
{
    DPRINTF(DPRINTF_EVT_NETWORK, "InitNetworkConfig()\n");
	EqpConfig *pEqpConfig = saGetEqpConfigPtr();
	
	pEqpConfig->network_config.network_mode = DFT_NETWORK_MODE;
    
    // Current IPV4 Setting
    //getipaddr(&(pEqpConfig->wifi_config.ip));
    //getmask(&(pEqpConfig->wifi_config.netmask));
    //getdefaultgateway(&(pEqpConfig->wifi_config.gateway));
    //get_Primary_dns(NM_DHCP_ENABLED, &(pEqpConfig->wifi_config.dns1));
    //get_Secondary_dns(NM_DHCP_ENABLED, &(pEqpConfig->wifi_config.dns2));
    // Save WiFi MAC address
    NetMACAddressGet(pEqpConfig->network_config.mac_addr);

    //DPRINTF(DPRINTF_EVT_NETWORK, "MAC = %02X:%02X:%02X:%02X:%02X:%02X\n",
    //pEqpConfig->wifi_config.mac_addr[0],pEqpConfig->wifi_config.mac_addr[1],pEqpConfig->wifi_config.mac_addr[2], 
    //pEqpConfig->wifi_config.mac_addr[3],pEqpConfig->wifi_config.mac_addr[4],pEqpConfig->wifi_config.mac_addr[5]);

    //DPRINTF(DPRINTF_EVT_NETWORK, "IP=%08X, MASK=%08X, GW=%08X, DNS1=%08X, DNS2=%08X\n", 
    //pEqpConfig->wifi_config.ip, pEqpConfig->wifi_config.netmask, pEqpConfig->wifi_config.gateway, pEqpConfig->wifi_config.dns1, pEqpConfig->wifi_config.dns2);
    
    pEqpConfig->network_config.ip = DFT_CURRENT_IP;
    pEqpConfig->network_config.netmask = DFT_CURRENT_NETMASK;
    pEqpConfig->network_config.gateway = DFT_CURRENT_GATEWAY;
    // read WiFi MAC address from CC3100
    pEqpConfig->network_config.dns1 = DFT_CURRENT_DNS1; // all-zero
    pEqpConfig->network_config.dns2 = DFT_CURRENT_DNS2; // all-zero
    pEqpConfig->network_config.fixed_ip_config = DFT_FIXED_IP;
    pEqpConfig->network_config.fixed_netmask_config = DFT_FIXED_NETMASK;
    pEqpConfig->network_config.fixed_gateway_config = DFT_FIXED_GATEWAY;
    pEqpConfig->network_config.fixed_dns1_config = DFT_FIXED_DNS1;
    pEqpConfig->network_config.fixed_dns2_config = DFT_FIXED_DNS2;

    // Save device IPv4 network info.
    //SaveNetworkInfo();

}

void InitHostConfig()
{
    DPRINTF(DPRINTF_EVT_NETWORK, "InitHostConfig()\n");
	EqpConfig *pEqpConfig = saGetEqpConfigPtr();

	pEqpConfig->host_config.config_version = DFT_CONFIG_VERSION;	
    strcpy(pEqpConfig->host_config.company, DFT_COMPANY_NAME);
    strcpy(pEqpConfig->host_config.model_name, DFT_MODEL_NAME);
    strcpy(pEqpConfig->host_config.device_name, DFT_DEVICE_NAME);
    strcpy(pEqpConfig->host_config.serial_no, DFT_SERIAL_NO);
    strcpy(pEqpConfig->host_config.hw_id, DFT_HW_ID);
    memset(pEqpConfig->host_config.password, 0, PASSWORD_STRING_SIZE);

    return;
}

void UpdateCurrentIP(void)
{
    EqpConfig *pEqpConfig = saGetEqpConfigPtr();
    // Current IPV4 Setting
    getipaddr(&(pEqpConfig->network_config.ip));
    getmask(&(pEqpConfig->network_config.netmask));
    getdefaultgateway(&(pEqpConfig->network_config.gateway));
    get_Primary_dns(NM_DHCP_ENABLED, &(pEqpConfig->network_config.dns1));
    get_Secondary_dns(NM_DHCP_ENABLED, &(pEqpConfig->network_config.dns2));

    DPRINTF(DPRINTF_EVT_NETWORK, "MAC = %02X:%02X:%02X:%02X:%02X:%02X\n",\
    pEqpConfig->network_config.mac_addr[0],pEqpConfig->network_config.mac_addr[1],pEqpConfig->network_config.mac_addr[2], \
    pEqpConfig->network_config.mac_addr[3],pEqpConfig->network_config.mac_addr[4],pEqpConfig->network_config.mac_addr[5]);

    DPRINTF(DPRINTF_EVT_NETWORK, "IP=%08X, MASK=%08X, GW=%08X, DNS1=%08X, DNS2=%08X\n", \
    pEqpConfig->network_config.ip, pEqpConfig->network_config.netmask, pEqpConfig->network_config.gateway, pEqpConfig->network_config.dns1, pEqpConfig->network_config.dns2);

    return;
}

void InitFactoryDefault()
{
    DPRINTF(DPRINTF_EVT_FLASH, "\nInitFactoryDefault()\n");
    InitHostConfig();    
    InitNetworkConfig();
}

void InitSystemConfig()
{
    InitFactoryDefault();
    /*
    DPRINTF(DPRINTF_EVT_NETWORK, "1)GW MAC:%02X:%02X:%02X:%02X:%02X:%02X\n\r",
                pEqpConfig->network_config.mac_addr[0], pEqpConfig->network_config.mac_addr[1],
    			pEqpConfig->network_config.mac_addr[2], pEqpConfig->network_config.mac_addr[3],
    			pEqpConfig->network_config.mac_addr[4], pEqpConfig->network_config.mac_addr[5]);

    */    
    UpdateCurrentIP();
}

