#include "common.h"

int main(void)
{
	key_t key = ftok(PROJ_PATH, PROJ_ID);
	int msgid = msgget(key, IPC_CREAT|0666);

	struct msgbuffer msg;
	char *delim = ":";
	char *p_str = NULL;
	int pid = 0;
	while(1)
	{
		bzero(&msg, sizeof(msg));

		//send msg.mtext to msgid
		//0:blocking send.if msg queue is full, waiting here.
		msgrcv(msgid, &msg, MSGSIZE, J2R, 0);

		printf("from config_slave: %s\n", msg.mtext);
		p_str = strtok(msg.mtext, delim);
		int pid = atoi(strtok(NULL, delim));
		printf("pid:%d\n", pid);
		printf("rev_msg:%s\n", p_str);
		int num = strncmp(p_str, "fix_ip mode", 11);
		kill(pid, SIGQUIT);
		system("sudo dhcpcd -k eth0");
        sleep(1);
	    system("sudo dhcpcd -n eth0");
        //sleep(3);
		chdir("/home/pi/lora0427/lora/packet_forwarder/basic_pkt_fwd");
		system("sudo ./basic_pkt_fwd &");

        //system("sudo systemctl restart basic_pkt_fwd");
		/*
		if(num == 0)
		{
			chdir("/home/pi/lora0427/lora/packet_forwarder/basic_pkt_fwd");
			system("sudo ./basic_pkt_fwd &");
			system("sudo dhcpcd -n eth0");
		}
		else
		{
			chdir("/home/pi/lora0427/lora/packet_forwarder/basic_pkt_fwd");
			system("sudo ./basic_pkt_fwd &");
			printf("dhcpcd -n OK!\n");
		}
		*/
		printf("OK to restart basic_pkt_fwd service....\n");
	}

	return 0;
}
