#ifndef __LOG_H__
#define __LOG_H__

int log_puts(char *fmt, ...);

#endif
