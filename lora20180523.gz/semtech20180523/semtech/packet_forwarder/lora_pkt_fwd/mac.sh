#!/bin/bash
ifconfig eth0|grep HWaddr > mac_1
sed -n -f sedlist mac_1 > mac_2
