#include "debug.h"

#define LOG(x...)                       printf(x)
#define DEBUG_MAX_CLIENT_NUM            (10)
#define DEBUG_MAX_BUF_LEN               (1024)

void debug_evt(void);
void *debug_client_thread(void *arg);

typedef struct{
    bool sta;
    int id;
    int socket;
    pthread_t thread;
    struct sockaddr_in addr;
    socklen_t  addrlen;
}debug_client_t;

typedef struct{
    pthread_t thread;
    int socket;
    uint16_t port;
    debug_client_t client[DEBUG_MAX_CLIENT_NUM];
}debug_t;

debug_t debug;

void debug_init(void)
{
    int ret;
    ret = pthread_create( &debug.thread, NULL, (void * (*)(void *))debug_evt, NULL);
    if (ret != 0) {
        LOG("[debug] Create thread error\n");
        return;
    }
    debug.port = 2222;

    close(debug.socket);
}

void debug_deinit(void)
{
    LOG("[debug] Create thread error\n");
    pthread_cancel(debug.thread);
}

void debug_evt(void)
{
    struct sockaddr_in addr;
    int ret;

    debug.socket = socket(AF_INET, SOCK_STREAM, 0);

    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons(debug.port);

    bind(debug.socket, (struct sockaddr*)&addr, sizeof(addr));
    listen(debug.socket, 10);

    while (!exit_sig && !quit_sig){
        debug_client_t *cskt;
        int i;
        for(i=0; i<DEBUG_MAX_CLIENT_NUM; i++){
            if(debug.client[i].sta == false){
                cskt = &debug.client[i];
                break;
            }
        }
        if(i == DEBUG_MAX_CLIENT_NUM){
            continue;
        }
        cskt->socket = accept(debug.socket, (struct sockaddr*)&cskt->addr, &cskt->addrlen);
        cskt->sta = true;
        cskt->id = i;
        ret = pthread_create(&cskt->thread, NULL, debug_client_thread, cskt);
        if (ret != 0) {
            LOG("[debug] debug_evt create thread error\n");
        }
    }
}

void debug_log(uint8_t *buf, int len)
{
    while(len--){
        printf("%02X ", *buf++);
    }
    printf("\n");
}

void debug_tx_pkt_push(uint8_t *buf, int len)
{
    //
    struct lgw_pkt_tx_s beacon_pkt;
    /* beacon packet parameters */
    beacon_pkt.tx_mode = ON_GPS; /* send on PPS pulse */
    beacon_pkt.rf_chain = 0; /* antenna A */
    beacon_pkt.rf_power = 14;
    beacon_pkt.modulation = MOD_LORA;
    beacon_pkt.bandwidth = BW_125KHZ;
    beacon_pkt.datarate = DR_LORA_SF9;
    beacon_pkt.coderate = CR_LORA_4_5;
    beacon_pkt.invert_pol = false;
    beacon_pkt.preamble = 10;
    beacon_pkt.no_crc = true;
    beacon_pkt.no_header = true;
    beacon_pkt.size = 17;
}

void *debug_client_thread(void *arg)
{
    debug_client_t *cskt = (debug_client_t *)arg;
    uint8_t buf[DEBUG_MAX_BUF_LEN];
    int len;

    LOG("[debug] open client %d\n", cskt->id);

    while (!exit_sig && !quit_sig){
        len = recv(cskt->socket, (void *)buf, DEBUG_MAX_BUF_LEN, 0);
        if(len > 0){
            printf("RX: ");
            debug_log(buf, len);
        }else{
            break;
        }
    }

    LOG("[debug] close client %d\n", cskt->id);
    cskt->sta = false;
    close(cskt->socket);

    return NULL;
}
