#include <string.h>
#include <stdio.h>
#include <stdlib.h> // for system()
#include <unistd.h> // 
#include <arpa/inet.h> // for htonl()
#include <string.h>

#include <sys/socket.h> // for inet_ntoa()
#include <netinet/in.h>

#include <sys/stat.h> // for stat()
#include <sys/types.h>
#include <fcntl.h>

#include <strings.h> // for bzero()

#include "debug_setting.h"
#include "cmd_process.h"
#include "g_config_data.h"
#include "json_rdwr.h"


int pre_networkmode;
extern int exchange_flag;

//extern "C" void setConfigData(IpssConfigData *pConfigData);
void getDeviceConfig(DeviceConfigData *pDeviceData)
{
    //initialize structure
    //DeviceConfig myConfig;
    EqpConfig *pEqpConfig = saGetEqpConfigPtr(); 
    unsigned long network_address;
    Gatewayconfig *pGatewayconfig = saGetGatewayconfig();
    int int32_val;
    float float_val;
    unsigned short uint16_val;
    unsigned long long uint64_val;   


    DPRINTF(DPRINTF_EVT_NETWORK, "getDeviceConfig()\n");

#if 0
    //prepare wipss_config data
    pDeviceData->config_version = DFT_CONFIG_VERSION;

    pDeviceData->dhcp = pEqpConfig->wifi_config.network_mode;
    DPRINTF(DPRINTF_EVT_NETWORK, "pDeviceData->dhcp = %d\n",pDeviceData->dhcp);

    strcpy(pDeviceData->device_name, pEqpConfig->host_config.device_name);

    strcpy(pDeviceData->serialno, pEqpConfig->host_config.serial_no);

    strcpy(pDeviceData->company, pEqpConfig->host_config.company);
    
    strcpy(pDeviceData->modelname, pEqpConfig->host_config.model_name);
    
    strcpy(pDeviceData->hwID, pEqpConfig->host_config.hw_id);

    strcpy(pDeviceData->version, DFT_VERSION);

    strcpy(pDeviceData->built_date, DFT_BUILT_DATE);

    // ethernet MAC address
    memcpy(pDeviceData->mac_addr, pEqpConfig->wifi_config.mac_addr, MAC_ADDRESS_SIZE);

    
    if(pEqpConfig->wifi_config.network_mode == NM_DHCP_ENABLED){
        network_address = htonl(pEqpConfig->wifi_config.ip);        
    }
    else {
        network_address = htonl(pEqpConfig->wifi_config.fixed_ip_config);        
    }
    
    DPRINTF(DPRINTF_EVT_NETWORK, "IP = %08X\n", network_address);
    pDeviceData->ipaddr = network_address;
    pDeviceData->fixed_ip_config = htonl(pEqpConfig->wifi_config.fixed_ip_config);        

    // netmask
    //pConfigData->netmask = htonl(pEqpConfig->wifi_config.netmask);
    if(pEqpConfig->wifi_config.network_mode == NM_DHCP_ENABLED)
        network_address = htonl(pEqpConfig->wifi_config.netmask);
    else
        network_address = htonl(pEqpConfig->wifi_config.fixed_netmask_config);
    
    DPRINTF(DPRINTF_EVT_NETWORK, "NETMASK = %08X\n", network_address);
    pDeviceData->netmask = network_address;
    pDeviceData->fixed_netmask_config = network_address;

    // default gateway
    //pConfigData->gw = htonl(pEqpConfig->wifi_config.gateway);
    if(pEqpConfig->wifi_config.network_mode == NM_DHCP_ENABLED)
        network_address = htonl(pEqpConfig->wifi_config.gateway);
    else
        network_address = htonl(pEqpConfig->wifi_config.fixed_gateway_config);
    
    DPRINTF(DPRINTF_EVT_NETWORK, "GATEWAY = %08X\n", network_address);
    pDeviceData->gw = network_address;
    pDeviceData->fixed_gateway_config = network_address;
#else
    /*
    typedef struct _DeviceConfigData {
   unsigned char  config_version;   //1, default 1
   unsigned char  dhcp;             //2, 0: disable, 1: enable, default:0
   unsigned char  mac_addr[6];      //8,
   char   device_name[16];   //24, default LoRaGW
   char   serialno[16];     //40, 123456789012345   
   unsigned long ipaddr;   //44, MSB, network order. 192.168.0.2 ==> current
   unsigned long netmask;  //48,MSB --255.255.255.0 ==> current
   unsigned long gw;       //52, MSB -- 192.168.0.1 ==> current
   
   //Jeffrey2018.04.18: newly added
   unsigned long fixed_ip_config; //56,  book-keep as fixed IP (network mode) of IPv4 IP
   unsigned long fixed_netmask_config; //60,  subnet mask
   unsigned long fixed_gateway_config; //64, default gateway  
   //Jeffrey2018.04.18: newly added
   
   char   company[24];      //88, MFG
   char   modelname[16];    //104, MFG
   char   hwID[16];         //120, MFG
   unsigned char version[8]; //128, decided by FW
   unsigned char built_date[16];  //144,  decided by FW
   unsigned char reserved[880];//1024
}  __attribute__((packed)) DeviceConfigData;
    */
    int i;
    unsigned long *pNetworkAddress;
    unsigned char *pDataPtr = (unsigned char *)pDeviceData;
    unsigned char *pGWConfigPtr;
    LoRaGatewayParam lora_gw_param;
    
    *pDataPtr = DFT_CONFIG_VERSION;
    pDataPtr += 1;
    *pDataPtr = pEqpConfig->network_config.network_mode;
    pDataPtr += 1;

    for(i = 0; i < 6 ; i++){
        *(pDataPtr + i) = pEqpConfig->network_config.mac_addr[i];
    }
    pDataPtr += 6;
    //device_name[16]
    memcpy(pDataPtr, pEqpConfig->host_config.device_name, 16);
    pDataPtr += 16;

    //serialno[16];
    memcpy(pDataPtr, pEqpConfig->host_config.serial_no, 16);
    pDataPtr += 16;

    pNetworkAddress = (unsigned long *)pDataPtr;
    // ipaddr, netmask, gw, fixed_ip_config, fixed_netmask_config, fixed_gateway_config    
    network_address = htonl(pEqpConfig->network_config.ip);
    memcpy(pNetworkAddress, &network_address, 4);
    pNetworkAddress += 1;

    network_address = htonl(pEqpConfig->network_config.netmask);
    memcpy(pNetworkAddress, &network_address, 4);
    pNetworkAddress += 1;

    network_address = htonl(pEqpConfig->network_config.gateway);
    memcpy(pNetworkAddress, &network_address, 4);
    pNetworkAddress += 1;

    network_address = htonl(pEqpConfig->network_config.fixed_ip_config);
    memcpy(pNetworkAddress, &network_address, 4);
    pNetworkAddress += 1;

    network_address = htonl(pEqpConfig->network_config.fixed_netmask_config);
    memcpy(pNetworkAddress, &network_address, 4);
    pNetworkAddress += 1;

    network_address = htonl(pEqpConfig->network_config.fixed_gateway_config);
    memcpy(pNetworkAddress, &network_address, 4);
    pNetworkAddress += 1;

    // locate unsigned char pointer to 'company' address
    pDataPtr = (unsigned char *)pDeviceData;
    pDataPtr += 64;
    
    // company[24]
    memcpy(pDataPtr, pEqpConfig->host_config.company, COMPANY_STRING_SIZE);
    pDataPtr += COMPANY_STRING_SIZE;

    // modelname[16]
    memcpy(pDataPtr, pEqpConfig->host_config.model_name, MODEL_NAME_STRING_SIZE);
    pDataPtr += MODEL_NAME_STRING_SIZE;

    // hwID[16]
    memcpy(pDataPtr, pEqpConfig->host_config.hw_id, HW_ID_STRING_SIZE);
    pDataPtr += HW_ID_STRING_SIZE;

    // version[8]
    strcpy((char *)pDataPtr, (const char *)DFT_VERSION);
    pDataPtr += VERSION_STRING_SIZE;

    // built_date[16]
    strcpy((char *)pDataPtr, (const char *)DFT_BUILT_DATE);
    pDataPtr += BUILT_DATE_STRING_SIZE;
                                            
    // reserved[880]
    pGWConfigPtr = pDataPtr;
    memset(pDataPtr, 0, 880);

    //fill out LoRaGatewayParam
    //DPRINTF(DPRINTF_EVT_NETWORK, "sizeof(LgwConfRxrf)=%d\n", sizeof(LgwConfRxrf));
    //DPRINTF(DPRINTF_EVT_NETWORK, "sizeof(LgwConfRxif)=%d\n", sizeof(LgwConfRxif));
    //DPRINTF(DPRINTF_EVT_NETWORK, "sizeof(LgwTxGain)=%d\n", sizeof(LgwTxGain));
    //DPRINTF(DPRINTF_EVT_NETWORK, "sizeof(LgwTxGainLut)=%d\n", sizeof(LgwTxGainLut));
    DPRINTF(DPRINTF_EVT_NETWORK, "sizeof(LoRaGatewayParam)=%d\n", sizeof(LoRaGatewayParam));

    memset(&lora_gw_param, 0, sizeof(LoRaGatewayParam));

    // SX1301_config.boardconf
    // lorawan_public(1)
    //DPRINTF(DPRINTF_EVT_NETWORK, "lorawan_public=%d\n", pGatewayconfig->SX1301_config.boardconf.lorawan_public);
    if(pGatewayconfig->SX1301_config.boardconf.lorawan_public)
       lora_gw_param.lorawan_public = 1;
    else
        lora_gw_param.lorawan_public = 0;    
    // clksrc(1)
    lora_gw_param.clksrc = pGatewayconfig->SX1301_config.boardconf.clksrc;
    //DPRINTF(DPRINTF_EVT_NETWORK, "clksrc=%d\n", pGatewayconfig->SX1301_config.boardconf.clksrc);

    int index;
    // SX1301_config.rfconf[2]
    // bool enable
    // uint32_t freq_hz;
    // float rssi_offset;
    // enum type
    // bool tx_enable
    for(index = 0; index < 2; index++) {
        //DPRINTF(DPRINTF_EVT_NETWORK, "rfconf[%d].enable=%d\n", index, pGatewayconfig->SX1301_config.rfconf[index].enable);
        if(pGatewayconfig->SX1301_config.rfconf[index].enable)
            lora_gw_param.rfconf[index].enable = 1;
        else
            lora_gw_param.rfconf[index].enable = 0;
        //freq_hz
        //DPRINTF(DPRINTF_EVT_NETWORK, "rfconf[%d].freq_hz=%d\n", index, pGatewayconfig->SX1301_config.rfconf[index].freq_hz);
        //e.g. '470600000'
        int32_val = htonl(pGatewayconfig->SX1301_config.rfconf[index].freq_hz);
        memcpy(&(lora_gw_param.rfconf[index].freq_hz), &int32_val, sizeof(int32_val));
        //rssi_offset
        //e.g. '-166.0'
        //DPRINTF(DPRINTF_EVT_NETWORK, "rfconf[%d].rssi_offset=%f\n", index, pGatewayconfig->SX1301_config.rfconf[index].rssi_offset);
        float_val = pGatewayconfig->SX1301_config.rfconf[index].rssi_offset;
        memcpy(&(lora_gw_param.rfconf[index].rssi_offset), &float_val, sizeof(float_val));                
        // SX1255, SX1257, radio type
        // enum lgw_radio_type_e {
    	// LGW_RADIO_TYPE_NONE,
	    // LGW_RADIO_TYPE_SX1255,
        //	LGW_RADIO_TYPE_SX1257
        // };
        //DPRINTF(DPRINTF_EVT_NETWORK, "rfconf[%d].type=%d\n", index, pGatewayconfig->SX1301_config.rfconf[index].type);        
        lora_gw_param.rfconf[index].type = pGatewayconfig->SX1301_config.rfconf[index].type;        
        // tx_enable
        //DPRINTF(DPRINTF_EVT_NETWORK, "rfconf[%d].tx_enable=%d\n", index, pGatewayconfig->SX1301_config.rfconf[index].tx_enable);
        if(pGatewayconfig->SX1301_config.rfconf[index].tx_enable)
            lora_gw_param.rfconf[index].tx_enable = 1;
        else
            lora_gw_param.rfconf[index].tx_enable = 0;
    }
        
    // SX1301_config.ifconfig[10]
    for(index = 0; index < 10; index++){
        DPRINTF(DPRINTF_EVT_NETWORK, "ifconf[%d].enable=%d\n", index, pGatewayconfig->SX1301_config.ifconf[index].enable);
        lora_gw_param.ifconf[index].enable = pGatewayconfig->SX1301_config.ifconf[index].enable;        
        DPRINTF(DPRINTF_EVT_NETWORK, "ifconf[%d].rf_chain=%d\n", index, pGatewayconfig->SX1301_config.ifconf[index].rf_chain);
        lora_gw_param.ifconf[index].rf_chain = pGatewayconfig->SX1301_config.ifconf[index].rf_chain;        

        //freq_hz
        DPRINTF(DPRINTF_EVT_NETWORK, "ifconf[%d].freq_hz=%d\n", index, pGatewayconfig->SX1301_config.ifconf[index].freq_hz);
        int32_val = htonl(pGatewayconfig->SX1301_config.ifconf[index].freq_hz);
        memcpy(&(lora_gw_param.ifconf[index].freq_hz), &int32_val, sizeof(int32_val));
        // bandwidth
        //DPRINTF(DPRINTF_EVT_NETWORK, "ifconf[%d].bandwidth=%d\n", index, pGatewayconfig->SX1301_config.ifconf[index].bandwidth);
        int32_val = htonl(pGatewayconfig->SX1301_config.ifconf[index].bandwidth);
        memcpy(&(lora_gw_param.ifconf[index].bandwidth), &int32_val, sizeof(int32_val));

        // datarate
        //DPRINTF(DPRINTF_EVT_NETWORK, "ifconf[%d].datarate=%d\n", index, pGatewayconfig->SX1301_config.ifconf[index].datarate);        
        int32_val = htonl(pGatewayconfig->SX1301_config.ifconf[index].datarate);
        memcpy(&(lora_gw_param.ifconf[index].datarate), &int32_val, sizeof(int32_val));

        // sync_word_size
        //DPRINTF(DPRINTF_EVT_NETWORK, "ifconf[%d].sync_word_size=%d\n", index, pGatewayconfig->SX1301_config.ifconf[index].sync_word_size);        
        lora_gw_param.ifconf[index].sync_word_size = pGatewayconfig->SX1301_config.ifconf[index].sync_word_size;
        
        // sync_word
        //DPRINTF(DPRINTF_EVT_NETWORK, "ifconf[%d].sync_word=%d\n", index, pGatewayconfig->SX1301_config.ifconf[index].sync_word);
        uint64_val = pGatewayconfig->SX1301_config.ifconf[index].sync_word;
        memcpy(&(lora_gw_param.ifconf[index].sync_word), &uint64_val, sizeof(uint64_val));        
    }

    // SX1301_config.txlut
    // lut[TX_GAIN_LUT_SIZE_MAX]
    // size
    for(index = 0; index < 16; index++){
        //DPRINTF(DPRINTF_EVT_NETWORK, "[%d] dig_gain = %d\n", index, pGatewayconfig->SX1301_config.txlut.lut[index].dig_gain);
        //DPRINTF(DPRINTF_EVT_NETWORK, "[%d] pa_gain = %d\n", index, pGatewayconfig->SX1301_config.txlut.lut[index].pa_gain);
        //DPRINTF(DPRINTF_EVT_NETWORK, "[%d] dac_gain = %d\n", index, pGatewayconfig->SX1301_config.txlut.lut[index].dac_gain);
        //DPRINTF(DPRINTF_EVT_NETWORK, "[%d] mix_gain = %d\n", index, pGatewayconfig->SX1301_config.txlut.lut[index].mix_gain);
        //DPRINTF(DPRINTF_EVT_NETWORK, "[%d] rf_power = %d\n", index, pGatewayconfig->SX1301_config.txlut.lut[index].rf_power);
         
        lora_gw_param.txlut.lut[index].dig_gain = pGatewayconfig->SX1301_config.txlut.lut[index].dig_gain;        
        lora_gw_param.txlut.lut[index].pa_gain = pGatewayconfig->SX1301_config.txlut.lut[index].pa_gain;        
        lora_gw_param.txlut.lut[index].dac_gain = pGatewayconfig->SX1301_config.txlut.lut[index].dac_gain;
        lora_gw_param.txlut.lut[index].mix_gain = pGatewayconfig->SX1301_config.txlut.lut[index].mix_gain;        
        lora_gw_param.txlut.lut[index].rf_power = pGatewayconfig->SX1301_config.txlut.lut[index].rf_power;
    }
    //DPRINTF(DPRINTF_EVT_NETWORK, "txlut.size = %d\n", pGatewayconfig->SX1301_config.txlut.size);
    lora_gw_param.txlut.size = pGatewayconfig->SX1301_config.txlut.size;
    

    // Gatewayconfig
    // gateway_config.gateway_ID[20]
    DPRINTF(DPRINTF_EVT_NETWORK, "gateway_ID =[%s]\n", pGatewayconfig->gateway_config.gateway_ID);
    memcpy(lora_gw_param.gateway_ID, pGatewayconfig->gateway_config.gateway_ID, 20);    
    
    // gateway_serv_addr[64]
    DPRINTF(DPRINTF_EVT_NETWORK, "serv_addr =[%s]\n", pGatewayconfig->gateway_config.serv_addr);
    memcpy(lora_gw_param.serv_addr, pGatewayconfig->gateway_config.serv_addr, 64);
    
    // gateway_config.serv_port_up[2];
    
    DPRINTF(DPRINTF_EVT_NETWORK, "serv_port_up = %d\n", pGatewayconfig->gateway_config.serv_port_up);
    uint16_val = htons(pGatewayconfig->gateway_config.serv_port_up);    
    memcpy(lora_gw_param.serv_port_up, &uint16_val, sizeof(uint16_val));

    // gateway_config.serv_port_down[2];
    DPRINTF(DPRINTF_EVT_NETWORK, "serv_port_down = %d\n", pGatewayconfig->gateway_config.serv_port_down);
    uint16_val = htons(pGatewayconfig->gateway_config.serv_port_down);
    memcpy(lora_gw_param.serv_port_down, &uint16_val, sizeof(uint16_val));

    // gateway_config.keepalive_time[4];
    DPRINTF(DPRINTF_EVT_NETWORK, "keepalive_time = %d\n", pGatewayconfig->gateway_config.keepalive_time);
    int32_val = htonl(pGatewayconfig->gateway_config.keepalive_time);
    memcpy(lora_gw_param.keepalive_time, &int32_val, sizeof(int32_val));

    // gateway_config.stat_interval[4];
    DPRINTF(DPRINTF_EVT_NETWORK, "stat_interval = %d\n", pGatewayconfig->gateway_config.stat_interval);
    int32_val = htonl(pGatewayconfig->gateway_config.stat_interval);
    memcpy(lora_gw_param.stat_interval, &int32_val, sizeof(int32_val));
    
    // gateway_config.timeout[4];
    DPRINTF(DPRINTF_EVT_NETWORK, "timeout = %d\n", pGatewayconfig->gateway_config.timeout);
    int32_val = htonl(pGatewayconfig->gateway_config.timeout);
    memcpy(lora_gw_param.timeout, &int32_val, sizeof(int32_val));

    // gateway_config.fwd_valid_pkt;
    DPRINTF(DPRINTF_EVT_NETWORK, "fwd_valid_pkt =%d\n", pGatewayconfig->gateway_config.fwd_valid_pkt);
    lora_gw_param.fwd_valid_pkt = pGatewayconfig->gateway_config.fwd_valid_pkt;
    // gateway_config.fwd_error_pkt;
    DPRINTF(DPRINTF_EVT_NETWORK, "fwd_error_pkt =%d\n", pGatewayconfig->gateway_config.fwd_error_pkt);
    lora_gw_param.fwd_error_pkt = pGatewayconfig->gateway_config.fwd_error_pkt;
    
    // gateway_config.nocrc_pkt;
    DPRINTF(DPRINTF_EVT_NETWORK, "fwd_nocrc_pkt =%d\n", pGatewayconfig->gateway_config.fwd_nocrc_pkt);
    lora_gw_param.fwd_nocrc_pkt = pGatewayconfig->gateway_config.fwd_nocrc_pkt;    

    memcpy(pGWConfigPtr, &lora_gw_param, sizeof(LoRaGatewayParam));
    


/*
    // SX1301_config.boardconf
    // lorawan_public(1)
    if(pGatewayconfig->SX1301_config.boardconf.lorawan_public)
        *pDataPtr = 1;
    else
        *pDataPtr = 0;
    pDataPtr += 1;
    // clksrc(1)
    *pDataPtr = pGatewayconfig->SX1301_config.boardconf.clksrc;
    pDataPtr += 1;

    int index;
    // SX1301_config.rfconf[2]
    // bool enable
    // uint32_t freq_hz;
    // float rssi_offset;
    // enum type
    // bool tx_enable
    for(index = 0; index < 2; index++) {
        *pDataPtr = pGatewayconfig->SX1301_config.rfconf[index].enable;
        pDataPtr += 1;
    
        pUint32Type = (unsigned int*)pDataPtr;
        *pUint32Type = pGatewayconfig->SX1301_config.rfconf[index].freq_hz;
        pDataPtr += 4;
        // SX1255, SX1257, radio type
        *pDataPtr = pGatewayconfig->SX1301_config.rfconf[index].type;
        pDataPtr += 1;
        // tx_enable
        *pDataPtr = pGatewayconfig->SX1301_config.rfconf[index].tx_enable;
        pDataPtr += 1;
    }
        
    // SX1301_config.ifconfig[10]
    for(index = 0; index < 10; index++){
        *pDataPtr = pGatewayconfig->SX1301_config.ifconf[index].enable;
        pDataPtr += 1;
        *pDataPtr = pGatewayconfig->SX1301_config.ifconf[index].rf_chain;
        pDataPtr += 1;

        //freq_hz
        pUint32Type = (unsigned int *)pDataPtr;
        *pUint32Type = pGatewayconfig->SX1301_config.ifconf[index].freq_hz;
        pDataPtr += 4;
        // bandwidth
        pUint32Type = (unsigned int *)pDataPtr;
        *pUint32Type = pGatewayconfig->SX1301_config.ifconf[index].bandwidth;
        pDataPtr += 4;

        // datarate
        pUint32Type = (unsigned int *)pDataPtr;
        *pUint32Type = pGatewayconfig->SX1301_config.ifconf[index].datarate;
        pDataPtr += 4;

        // sync_word_size        
        *pDataPtr = pGatewayconfig->SX1301_config.ifconf[index].sync_word_size;
        pDataPtr += 1;
        // sync_word
        pLongLongType = (long long *)pDataPtr;
        *pLongLongType = pGatewayconfig->SX1301_config.ifconf[index].sync_word;
        pDataPtr += 8;
    }

    // SX1301_config.txlut
    // lut[TX_GAIN_LUT_SIZE_MAX]
    // size
    for(index = 0; index < 16; index++){
        *pDataPtr = pGatewayconfig->SX1301_config.txlut.lut[index].dig_gain;
        pDataPtr += 1;
        *pDataPtr = pGatewayconfig->SX1301_config.txlut.lut[index].pa_gain;
        pDataPtr += 1;
        *pDataPtr = pGatewayconfig->SX1301_config.txlut.lut[index].dac_gain;
        pDataPtr += 1;
        *pDataPtr = pGatewayconfig->SX1301_config.txlut.lut[index].mix_gain;
        pDataPtr += 1;
        *pDataPtr = pGatewayconfig->SX1301_config.txlut.lut[index].rf_power;
        pDataPtr += 1;
    }
    *pDataPtr = pGatewayconfig->SX1301_config.txlut.size;
    pDataPtr += 1;

    // Gatewayconfig
    // gateway_config.gateway_ID[20]
    memcpy(pDataPtr, pGatewayconfig->gateway_config.gateway_ID, 20);    
    pDataPtr += 20;
    // gateway_serv_addr[64]
    memcpy(pDataPtr, pGatewayconfig->gateway_config.serv_addr, 64);
    pDataPtr += 64;
    // gateway_config.serv_port_up[2];
    pUint16Type = (unsigned short *)pDataPtr;
    *pUint16Type = pGatewayconfig->gateway_config.serv_port_up;
    pDataPtr += 2;
    // gateway_config.serv_port_down[2];
    pUint16Type = (unsigned short *)pDataPtr;
    *pUint16Type = pGatewayconfig->gateway_config.serv_port_down;
    pDataPtr += 2;
    // gateway_config.keepalive_time[4];
    pUint32Type = (unsigned int *)pDataPtr;
    *pUint32Type = pGatewayconfig->gateway_config.keepalive_time;
    pDataPtr += 4;

    // gateway_config.stat_interval[4];
    pUint32Type = (unsigned int *)pDataPtr;
    *pUint32Type = pGatewayconfig->gateway_config.stat_interval;
    pDataPtr += 4;
    // gateway_config.timeout[4];
    pUint32Type = (unsigned int *)pDataPtr;
    *pUint32Type = pGatewayconfig->gateway_config.timeout;
    pDataPtr += 4;
    // gateway_config.fwd_valid_pkt;
    *pDataPtr = pGatewayconfig->gateway_config.fwd_valid_pkt;
    pDataPtr += 1;
    // gateway_config.fwd_error_pkt;
    *pDataPtr = pGatewayconfig->gateway_config.fwd_error_pkt;
    pDataPtr += 1;
    // gateway_config.nocrc_pkt;
    *pDataPtr = pGatewayconfig->gateway_config.fwd_nocrc_pkt;
    pDataPtr += 1;

    DPRINTF(DPRINTF_EVT_NETWORK, "sizeof(LoRaGatewayParam): pDataPtr(%d) - pGWConfigPtr(%d) = %d", pDataPtr, pGWConfigPtr, pDataPtr - pGWConfigPtr);
*/
#endif
    return;
}

void setDeviceConfig(DeviceConfigData *pDeviceData)
{
    int i, netmask_num=0;
    char fixip_buffer[50];
	//char fixgateway_buffer[50];
    char newip_buffer[50];
    char newgateway_buffer[50];
    char read_buf[1024];
    struct sockaddr_in addr1;
    //struct stat info;
    unsigned long ip = 0;
    unsigned char *pDataPtr = (unsigned char *)pDeviceData;
    //unsigned char val;
    //unsigned long *pNetworkAddress;
    LoRaGatewayParam *pLoRaGatewayParam;

    DPRINTF(DPRINTF_EVT_NETWORK, "setDeviceConfig()\n");

    EqpConfig *pEqpConfig = saGetEqpConfigPtr();

    Gatewayconfig *pGatewayconfig = saGetGatewayconfig();    
 
	bzero(read_buf, sizeof(read_buf));
	
    getcwd(read_buf, sizeof(read_buf));
    DPRINTF(DPRINTF_EVT_NETWORK, "getcwd(): %s\n", read_buf);

	FILE *fp_fixip = fopen("fix_ip.sh", "w+");
    
    //FILE *fp_fixip = fopen("fix_ip.sh", "w+");

	//setvbuf(fp_fixip, NULL, _IONBF, 0);
    //config_version
	//DPRINTF(DPRINTF_EVT_NETWORK, "config_version = %d\n",*pDataPtr);
    //pDataPtr += 1;
    //config_version
    //DPRINTF(DPRINTF_EVT_NETWORK, "dhcp = %d\n", *pDataPtr);

    //DPRINTF(DPRINTF_EVT_NETWORK, "pre_netwrokmode\n");
	pre_networkmode = pEqpConfig->network_config.network_mode;
    DPRINTF(DPRINTF_EVT_NETWORK, "pEqpConfig->network_config.network_mode(%d)\n", pre_networkmode);
    pEqpConfig->network_config.network_mode = pDeviceData->dhcp;
	//DPRINTF(DPRINTF_EVT_NETWORK,"***pre_networkmode:%d****\n", pre_networkmode);
    //pEqpConfig->network_config.network_mode = *pDataPtr;
	DPRINTF(DPRINTF_EVT_NETWORK,"---later_networkmode:%d---\n", pEqpConfig->network_config.network_mode);

    //unsigned char *pDataPtr;
    //unsigned long network_address;
    
    // config_version
    //strcpy(pEqpConfig->host_config.config_version, pDeviceData->config_version);
    //dhcp
    if(pDeviceData->dhcp == NM_DHCP_ENABLED){    
        DPRINTF(DPRINTF_EVT_NETWORK, "[SET]dhcp(%d):enabled\n", pDeviceData->dhcp);
    }
    else {
        DPRINTF(DPRINTF_EVT_NETWORK, "[SET]dhcp(%d):disabled\n", pDeviceData->dhcp);
    }

    //pEqpConfig->network_config.network_mode = pDeviceData->dhcp;
    //pEqpConfig->network_config.network_mode = pDeviceData->dhcp;

    //device_name
    DPRINTF(DPRINTF_EVT_NETWORK, "[SET]device_name = %s\n", pDeviceData->device_name);
    memcpy(pEqpConfig->host_config.device_name, pDeviceData->device_name, DEVICE_NAME_STRING_SIZE);
    //serialno
    //strcpy(pEqpConfig->host_config.serial_no, pDeviceData->serialno);



    // Set LoRa Parameters
    pDataPtr = (unsigned char *)pDeviceData;
    pDataPtr += (UPDATE_PAYLOAD_SIZE - LORA_PARAM_LEN);
    pLoRaGatewayParam = (LoRaGatewayParam *)pDataPtr;
    // start modifying ConfigMaster's LoRa parameters
    if(pLoRaGatewayParam->lorawan_public){
        pGatewayconfig->SX1301_config.boardconf.lorawan_public = true;
    }
    else {
        pGatewayconfig->SX1301_config.boardconf.lorawan_public = false;
    }
    DPRINTF(DPRINTF_EVT_NETWORK, "lorawan_public = %d\n", index, pGatewayconfig->SX1301_config.boardconf.lorawan_public);

    pGatewayconfig->SX1301_config.boardconf.clksrc = pLoRaGatewayParam->clksrc;
    DPRINTF(DPRINTF_EVT_NETWORK, "clksrc = %d\n", index, pGatewayconfig->SX1301_config.boardconf.clksrc); 

    int index;
    int int32_val;
    float float_val;
    unsigned short uint16_val;
    unsigned long long uint64_val; 

    for(index = 0; index < 2; index++){
        if(pLoRaGatewayParam->rfconf[index].enable)
            pGatewayconfig->SX1301_config.rfconf[index].enable = true;
        else
            pGatewayconfig->SX1301_config.rfconf[index].enable = false;
        
        DPRINTF(DPRINTF_EVT_NETWORK, "rfconf[%d].enable = %d\n", index, pGatewayconfig->SX1301_config.rfconf[index].enable); 

        memcpy(&int32_val, pLoRaGatewayParam->rfconf[index].freq_hz, sizeof(int32_val));
        pGatewayconfig->SX1301_config.rfconf[index].freq_hz = ntohl(int32_val);
        DPRINTF(DPRINTF_EVT_NETWORK, "rfconf[%d].freq_hz = %d\n", index, pGatewayconfig->SX1301_config.rfconf[index].freq_hz); 
        // rssi_offset
        // e.g. '-166.0'
        memcpy(&float_val, pLoRaGatewayParam->rfconf[index].rssi_offset, sizeof(float_val));
        pGatewayconfig->SX1301_config.rfconf[index].rssi_offset = float_val;
        DPRINTF(DPRINTF_EVT_NETWORK, "rfconf[%d].rssi_offset = %d\n", index, pGatewayconfig->SX1301_config.rfconf[index].rssi_offset); 
        // SX1255, SX1257, radio type
        // enum lgw_radio_type_e {
    	// LGW_RADIO_TYPE_NONE,
	    // LGW_RADIO_TYPE_SX1255,
        //	LGW_RADIO_TYPE_SX1257
        // };
        pGatewayconfig->SX1301_config.rfconf[index].type = pLoRaGatewayParam->rfconf[index].type;
        DPRINTF(DPRINTF_EVT_NETWORK, "rfconf[%d].type = %d\n", index, pGatewayconfig->SX1301_config.rfconf[index].type); 
        // tx_enable
        if(pLoRaGatewayParam->rfconf[index].tx_enable)
            pGatewayconfig->SX1301_config.rfconf[index].tx_enable = true;
        else
            pGatewayconfig->SX1301_config.rfconf[index].tx_enable = false;
        DPRINTF(DPRINTF_EVT_NETWORK, "rfconf[%d].tx_enable = %d\n", index, pGatewayconfig->SX1301_config.rfconf[index].tx_enable); 
    }

    for(index = 0; index < 10; index++){
        pGatewayconfig->SX1301_config.ifconf[index].enable = pLoRaGatewayParam->ifconf[index].enable;
        DPRINTF(DPRINTF_EVT_NETWORK, "ifconf[%d].enable = %d\n", index, pGatewayconfig->SX1301_config.ifconf[index].enable);
        pGatewayconfig->SX1301_config.ifconf[index].rf_chain = pLoRaGatewayParam->ifconf[index].rf_chain;
        DPRINTF(DPRINTF_EVT_NETWORK, "ifconf[%d].rf_chain = %d\n", index, pGatewayconfig->SX1301_config.ifconf[index].rf_chain);

        //freq.hz
        memcpy(&int32_val, pLoRaGatewayParam->ifconf[index].freq_hz, sizeof(int32_val));
        pGatewayconfig->SX1301_config.ifconf[index].freq_hz = ntohl(int32_val);
        DPRINTF(DPRINTF_EVT_NETWORK, "ifconf[%d].freq_hz = %d\n", index, pGatewayconfig->SX1301_config.ifconf[index].freq_hz);

        // bandwidth
        memcpy(&int32_val, pLoRaGatewayParam->ifconf[index].bandwidth, sizeof(int32_val));
        pGatewayconfig->SX1301_config.ifconf[index].bandwidth = ntohl(int32_val);         

        // datarate
        memcpy(&int32_val, pLoRaGatewayParam->ifconf[index].datarate, sizeof(int32_val));
        pGatewayconfig->SX1301_config.ifconf[index].datarate = ntohl(int32_val);         

        // sync_word_size
        pGatewayconfig->SX1301_config.ifconf[index].sync_word_size = pLoRaGatewayParam->ifconf[index].sync_word_size;

        // sync_word
        memcpy(&uint64_val, pLoRaGatewayParam->ifconf[index].sync_word, sizeof(uint64_val));
        pGatewayconfig->SX1301_config.ifconf[index].sync_word = uint64_val;
    }

    // SX1301_config.txlut
    // lut[TX_GAIN_LUT_SIZE_MAX]
    // size
    for(index = 0; index < 16; index++){
        pGatewayconfig->SX1301_config.txlut.lut[index].dig_gain = pLoRaGatewayParam->txlut.lut[index].dig_gain;
        DPRINTF(DPRINTF_EVT_NETWORK, "lut[%d].dig_gain = %d\n", index, pGatewayconfig->SX1301_config.txlut.lut[index].dig_gain);
        pGatewayconfig->SX1301_config.txlut.lut[index].pa_gain = pLoRaGatewayParam->txlut.lut[index].pa_gain;
        DPRINTF(DPRINTF_EVT_NETWORK, "lut[%d].pa_gain = %d\n", index, pGatewayconfig->SX1301_config.txlut.lut[index].pa_gain);
        pGatewayconfig->SX1301_config.txlut.lut[index].dac_gain = pLoRaGatewayParam->txlut.lut[index].dac_gain;
        pGatewayconfig->SX1301_config.txlut.lut[index].mix_gain = pLoRaGatewayParam->txlut.lut[index].mix_gain;
        DPRINTF(DPRINTF_EVT_NETWORK, "lut[%d].mix_gain = %d\n", index, pGatewayconfig->SX1301_config.txlut.lut[index].mix_gain);
        pGatewayconfig->SX1301_config.txlut.lut[index].rf_power = pLoRaGatewayParam->txlut.lut[index].rf_power;
        DPRINTF(DPRINTF_EVT_NETWORK, "lut[%d].rf_power = %d\n", index, pGatewayconfig->SX1301_config.txlut.lut[index].rf_power);
    }
    pGatewayconfig->SX1301_config.txlut.size = pLoRaGatewayParam->txlut.size;

    // Gatewayconfig
    // gateway_config.gateway_ID[20]
    DPRINTF(DPRINTF_EVT_NETWORK, "gateway_ID =[%s]\n", pLoRaGatewayParam->gateway_ID);    
    memcpy(pGatewayconfig->gateway_config.gateway_ID, pLoRaGatewayParam->gateway_ID, 20);
    
    // gateway_serv_addr[64]
    DPRINTF(DPRINTF_EVT_NETWORK, "serv_addr =[%s]\n", pLoRaGatewayParam->serv_addr);
    memcpy(pGatewayconfig->gateway_config.serv_addr, pLoRaGatewayParam->serv_addr, 64);
    
    // gateway_config.serv_port_up[2];
    memcpy(&uint16_val, pLoRaGatewayParam->serv_port_up, sizeof(uint16_val));    
    pGatewayconfig->gateway_config.serv_port_up = ntohs(uint16_val);     
    DPRINTF(DPRINTF_EVT_NETWORK, "serv_port_up = %d\n", pGatewayconfig->gateway_config.serv_port_up);

    // gateway_config.serv_port_down[2];
    memcpy(&uint16_val, pLoRaGatewayParam->serv_port_down, sizeof(uint16_val));    
    pGatewayconfig->gateway_config.serv_port_down = ntohs(uint16_val);     
    DPRINTF(DPRINTF_EVT_NETWORK, "serv_port_down = %d\n", pGatewayconfig->gateway_config.serv_port_down);

    // gateway_config.keepalive_time[4];
    memcpy(&int32_val, pLoRaGatewayParam->keepalive_time, sizeof(int32_val));
    pGatewayconfig->gateway_config.keepalive_time = ntohl(int32_val);    
    DPRINTF(DPRINTF_EVT_NETWORK, "keepalive_time = %d\n", pGatewayconfig->gateway_config.keepalive_time);

    //config.stat_interval[4];
    memcpy(&int32_val, pLoRaGatewayParam->stat_interval, sizeof(int32_val));
    pGatewayconfig->gateway_config.stat_interval = ntohl(int32_val);     
    DPRINTF(DPRINTF_EVT_NETWORK, "stat_interval = %d\n", pGatewayconfig->gateway_config.stat_interval);
    
    // gateway_config.timeout[4];
    memcpy(&int32_val, pLoRaGatewayParam->timeout, sizeof(int32_val));
    pGatewayconfig->gateway_config.timeout = ntohl(int32_val);     
    DPRINTF(DPRINTF_EVT_NETWORK, "timeout = %d\n", pGatewayconfig->gateway_config.timeout);

    // gateway_config.fwd_valid_pkt;    
    pGatewayconfig->gateway_config.fwd_valid_pkt = pLoRaGatewayParam->fwd_valid_pkt;
    DPRINTF(DPRINTF_EVT_NETWORK, "fwd_valid_pkt =%d\n", pGatewayconfig->gateway_config.fwd_valid_pkt);
    // gateway_config.fwd_error_pkt;    
    pGatewayconfig->gateway_config.fwd_error_pkt = pLoRaGatewayParam->fwd_error_pkt;
    DPRINTF(DPRINTF_EVT_NETWORK, "fwd_error_pkt =%d\n", pGatewayconfig->gateway_config.fwd_error_pkt);
    
    // gateway_config.nocrc_pkt;    
    pGatewayconfig->gateway_config.fwd_nocrc_pkt = pLoRaGatewayParam->fwd_nocrc_pkt;
    DPRINTF(DPRINTF_EVT_NETWORK, "fwd_nocrc_pkt =%d\n", pGatewayconfig->gateway_config.fwd_nocrc_pkt);
#if 1
    if(pEqpConfig->network_config.network_mode == NM_DHCP_DISABLED){
        pEqpConfig->network_config.fixed_ip_config = ntohl(pDeviceData->fixed_ip_config);
        pEqpConfig->network_config.fixed_netmask_config = ntohl(pDeviceData->fixed_netmask_config);
        pEqpConfig->network_config.fixed_gateway_config = ntohl(pDeviceData->fixed_gateway_config);
         if(pre_networkmode != pEqpConfig->network_config.network_mode)
	    {   
            //DPRINTF(DPRINTF_EVT_NETWORK, "fixed_ip = %s\n", inet_ntoa(ntohl(pEqpConfig->wifi_config.fixed_ip_config)));
            //DPRINTF(DPRINTF_EVT_NETWORK, "fixed_netmask = %s\n", inet_ntoa(ntohl(pEqpConfig->wifi_config.fixed_netmask_config)));
            //DPRINTF(DPRINTF_EVT_NETWORK, "fixed_gateway = %s\n", inet_ntoa(ntohl(pEqpConfig->wifi_config.fixed_gateway_config)));

            const char *str = ".";
            addr1.sin_addr.s_addr = htonl(pEqpConfig->network_config.fixed_netmask_config); 
            char *p = strtok(inet_ntoa(addr1.sin_addr), str);
            for(i=0; i<8; i++)
            {
                if((atoi(p)>>i)& 1)
                    netmask_num++;
            }
            
            while((p = strtok(NULL, (char const *)str)))
            {
                for(i=0; i<8; i++)
                {
                    if((atoi(p)>>i)& 1)
                        netmask_num++;
                }
            }	

            addr1.sin_addr.s_addr = htonl(pEqpConfig->network_config.fixed_ip_config); 
            sprintf((char * const)newip_buffer, "sudo ip addr add %s/%d dev eth0", inet_ntoa(addr1.sin_addr), netmask_num);
            if(system((const char *)newip_buffer))
               	printf("ip system is OK\n");	
		
            addr1.sin_addr.s_addr = htonl(pEqpConfig->network_config.fixed_gateway_config); 
            printf("new ip gateway:%s\n", inet_ntoa(addr1.sin_addr));
            sprintf(newgateway_buffer, "sudo ip route add %s dev eth0", inet_ntoa(addr1.sin_addr));
            if(system((const char *)newgateway_buffer))
			printf("gateway system is OK\n");

            DPRINTF(DPRINTF_EVT_NETWORK,"[json_rdwr] exchange_flag = %d\n",exchange_flag);
            json_rdwr(pGatewayconfig, pEqpConfig);

            DPRINTF(DPRINTF_EVT_NETWORK, "modify dhcpcd.conf\n");

            //system("sudo cp /etc/dhcpcd.conf /etc/dhcpcd.conf.bak");
            if(access(DFT_DHCP_CONFIG_PATHNAME, F_OK) == 0){
                DPRINTF(DPRINTF_EVT_NETWORK, "File: %s exist\n",DFT_DHCP_CONFIG_PATHNAME);
            }
            else {
                DPRINTF(DPRINTF_EVT_NETWORK, "File: backup %s as %s\n",DFT_DHCP_CONFIG_PATHNAME, DFT_DHCP_BACKUP_PATHNAME);
                //chmod rwx(421=7), sudo chmod o+w readme.txt: user/group/other
                system("sudo chmod o+w /etc/dhcpcd.conf");
                system("sudo cp /etc/dhcpcd.conf.bak /etc/dhcpcd.conf");    
            }
            //system("sudo cp /etc/dhcpcd.conf.bak /etc/dhcpcd.conf");
            fprintf(fp_fixip, "#!/bin/bash\n");
            fprintf(fp_fixip, "\techo \"interface eth0\" >> /etc/dhcpcd.conf\n");

            //fprintf(fp_fixip, "\techo \"static ip_address=%s\" >> /etc/dhcpcd.conf\n", inet_ntoa(ntohl(pEqpConfig->network_config.fixed_ip_config)));
            addr1.sin_addr.s_addr = ntohl(pEqpConfig->network_config.fixed_ip_config);            
            fprintf(fp_fixip, "\techo \"static ip_address=%s\" >> /etc/dhcpcd.conf\n", inet_ntoa(addr1.sin_addr));

            addr1.sin_addr.s_addr = ntohl(pEqpConfig->network_config.fixed_netmask_config);
            fprintf(fp_fixip, "\techo \"static domain_name_servers=%s\" >> /etc/dhcpcd.conf\n", inet_ntoa(addr1.sin_addr));
            //fprintf(fp_fixip, "\techo \"static domain_name_servers=%s\" >> /etc/dhcpcd.conf\n", inet_ntoa(ntohl(pEqpConfig->network_config.fixed_netmask_config)));
            addr1.sin_addr.s_addr = ntohl(pEqpConfig->network_config.fixed_gateway_config);
            fprintf(fp_fixip, "\techo \"static routers=%s\" >> /etc/dhcpcd.conf\n", inet_ntoa(addr1.sin_addr));
            //fprintf(fp_fixip, "\techo \"static routers=%s\" >> /etc/dhcpcd.conf\n", inet_ntoa(ntohl(pEqpConfig->network_config.fixed_gateway_config)));
            DPRINTF(DPRINTF_EVT_NETWORK,"******set fix_ip OK*******\n");
            fflush(fp_fixip);
            fclose(fp_fixip);
            system("sudo chmod +x ./fix_ip.sh");
            system("sudo ./fix_ip.sh");
            exchange_flag = 1;
            DPRINTF(DPRINTF_EVT_NETWORK, "exchange_flag = %d\n",exchange_flag);
        }
    }
    else {
        if(pre_networkmode != pEqpConfig->network_config.network_mode)
	    { 

            //struct stat info;
            //stat("ipaddr_1", &info);
			while(1)
            //while(info.st_size != 0)
            {
                //printf("ipaddr_1:%d\n", info.st_size);
                // while(ip != 0){
                ip = getipaddress();
                if(ip != 0){
                    addr1.sin_addr.s_addr = htonl(ip); 
                    printf("******ip:%s******\n", inet_ntoa(addr1.sin_addr));
                    sprintf(fixip_buffer, "sudo ip addr del %s dev eth0", inet_ntoa(addr1.sin_addr));
                    DPRINTF(DPRINTF_EVT_NETWORK, "%s\n",fixip_buffer);
                    system(fixip_buffer);
                }
                else
                    break;
            }
            system("sudo cp /etc/dhcpcd.conf.bak /etc/dhcpcd.conf");
            //printf("fix_ip:%s\n", inet_ntoa(pEqpConfig->network_config.fixed_ip_config));
            // addr1.sin_addr.s_addr = htonl(pEqpConfig->network_config.fixed_ip_config);
            //printf("del fix_ip:%s\n", inet_ntoa(pDeviceData->ipaddr));
            // sprintf(fixip_buffer, "sudo ip addr del %s dev eth0", inet_ntoa(addr1.sin_addr));
            // DPRINTF(DPRINTF_EVT_NETWORK, "%s\n",fixip_buffer);
            // system(fixip_buffer);
            //printf("del fix_ip gateway:%s\n", inet_ntoa(pDeviceData->gw));
            // addr1.sin_addr.s_addr = ntohl(pEqpConfig->network_config.fixed_gateway_config);;
            // DPRINTF(DPRINTF_EVT_NETWORK, "%s\n",fixip_buffer);
            // sprintf(fixgateway_buffer, "sudo ip route del %s dev eth0", inet_ntoa(addr1.sin_addr));
            // system(fixgateway_buffer);
            // system("sudo cp /etc/dhcpcd.conf.bak /etc/dhcpcd.conf");
            exchange_flag = 2;
            DPRINTF(DPRINTF_EVT_NETWORK, "exchange_flag = %d\n",exchange_flag);
        }
        DPRINTF(DPRINTF_EVT_NETWORK,"[json_rdwr] exchange_flag = %d\n",exchange_flag);
        json_rdwr(pGatewayconfig, pEqpConfig);
    }
    
    // ethernet MAC address    
    //DPRINTF(DPRINTF_EVT_NETWORK,"MAC=%02X:%02X:%02X:%02X:%02X:%02X\n",pDeviceData->mac_addr[0], pDeviceData->mac_addr[1],
    //pDeviceData->mac_addr[2], pDeviceData->mac_addr[3], pDeviceData->mac_addr[4], pDeviceData->mac_addr[5]);
#endif
    
    return;
}


