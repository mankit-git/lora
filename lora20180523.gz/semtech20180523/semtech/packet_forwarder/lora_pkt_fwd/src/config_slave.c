#include "common.h"

int main(void)
{
	key_t key = ftok(PROJ_PATH, PROJ_ID);
	int msgid = msgget(key, IPC_CREAT|0666);

	struct msgbuffer msg;
	char *delim = ":";
	char *p_str = NULL;
	int pid = 0;
	char cmd_buffer[200];
	int need_restart_service = 0;
	int need_rebind_nic = 0;

	printf("Start config_slave process ...\n");

	while(1)
	{
		bzero(&msg, sizeof(msg));

		//send msg.mtext to msgid
		//0:blocking send.if msg queue is full, waiting here.
		msgrcv(msgid, &msg, MSGSIZE, J2R, 0);

		printf("from config_slave: %s\n", msg.mtext);
		p_str = strtok(msg.mtext, delim);
		int pid = atoi(strtok(NULL, delim));
		printf("pid:%d\n", pid);
		printf("rev_msg:%s\n", p_str);
		int num = strncmp(p_str, "restart", 7);
		// system("sudo systemctl restart lrgateway");
		if(num == 0){
			need_restart_service = 1;
		}
		num = strncmp(p_str, "fix_ip mode", 11);
		if(num == 0) {
			need_restart_service = 1;
			need_rebind_nic = 1;
			
		}
		num = strncmp(p_str, "dhcp mode", 9);
		if(num == 0){
			need_restart_service = 1;
			need_rebind_nic = 1;			
		//chdir("/home/pi/lora0427/lora/packet_forwarder/basic_pkt_fwd");
		//system("sudo ./basic_pkt_fwd &");

        //system("sudo systemctl restart basic_pkt_fwd");
		/*
		if(num == 0)
		{
			chdir("/home/pi/lora0427/lora/packet_forwarder/basic_pkt_fwd");
			system("sudo ./basic_pkt_fwd &");
			system("sudo dhcpcd -n eth0");
		}
		else
		{
			chdir("/home/pi/lora0427/lora/packet_forwarder/basic_pkt_fwd");
			system("sudo ./basic_pkt_fwd &");
			printf("dhcpcd -n OK!\n");
		}
		*/
		}
		if(need_rebind_nic){
			system("sudo dhcpcd -k eth0");
        	sleep(1);
	    	system("sudo dhcpcd -n eth0");
			sleep(1);
			need_rebind_nic = 0;
		}

		if(need_restart_service){
			printf("kill pid = %d\n", pid);
			//kill(pid, SIGQUIT);
			sprintf(cmd_buffer, "sudo kill -9 %d", pid);
			printf("issue command:%s\n", cmd_buffer);
			system(cmd_buffer);

			printf("sudo systemctl restart pktfwd\n");
			system("sudo systemctl restart pktfwd");
			need_restart_service = 0;
		}

		
	}

	return 0;
}
