#include <iostream>  
#include <fstream> 
#include <string>   
#include <string.h>
#include <stdlib.h>
#include "json/json.h" 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "cmd_process.h"
#include "debug_setting.h"
#include "command_define.h"
#include "g_config_data.h"
#include "json_rdwr.h"

using namespace std; 

extern "C" void json_rdwr(Gatewayconfig *pGatewayconfig, EqpConfig *pEqpConfig);

Gatewayconfig  g_Gatewayconfig;

Gatewayconfig* saGetGatewayconfig(void)
{
	return &g_Gatewayconfig;
}

void json_rdwr(Gatewayconfig *pGatewayconfig, EqpConfig *pEqpConfig)
{
	std::ofstream fout;
	struct sockaddr_in addr1;
	fout.open("local_conf.json");
	//parse_SX1301_configuration("global_conf.json");
	//parse_gateway_configuration("global_conf.json");

	/************************************************************/
	/**********************gateway_config***********************/
	Json::Value json_gateway;
	json_gateway["gateway_ID"] = Json::Value(pGatewayconfig->gateway_config.gateway_ID);
	json_gateway["server_address"] = Json::Value(pGatewayconfig->gateway_config.serv_addr);
	json_gateway["serv_port_up"] = Json::Value(pGatewayconfig->gateway_config.serv_port_up);
	json_gateway["serv_port_down"] = Json::Value(pGatewayconfig->gateway_config.serv_port_down);
	json_gateway["keepalive_interval"] = Json::Value(pGatewayconfig->gateway_config.keepalive_time);
	json_gateway["stat_interval"] = Json::Value(pGatewayconfig->gateway_config.stat_interval);
	json_gateway["push_timeout_ms"] = Json::Value(pGatewayconfig->gateway_config.timeout);
	json_gateway["forward_crc_valid"] = Json::Value(pGatewayconfig->gateway_config.fwd_valid_pkt);
	json_gateway["forward_crc_error"] = Json::Value(pGatewayconfig->gateway_config.fwd_error_pkt);
	json_gateway["forward_crc_disabled"] = Json::Value(pGatewayconfig->gateway_config.fwd_nocrc_pkt);
	
	/************************************************************/

	/********************server_name_config*********************/
	Json::Value json_servconf;
	printf("**************server_name:%s******************\n", pEqpConfig->host_config.device_name);
	addr1.sin_addr.s_addr = ntohl(pEqpConfig->network_config.fixed_ip_config);
	printf("**************server_fix_ip:%x******************\n", inet_ntoa(addr1.sin_addr));
	json_servconf["server_name"] = Json::Value(pEqpConfig->host_config.device_name);
	json_servconf["networkmode"] = Json::Value(pEqpConfig->network_config.network_mode);
	json_servconf["fixed_ip"] = Json::Value(inet_ntoa(addr1.sin_addr));
	addr1.sin_addr.s_addr = ntohl(pEqpConfig->network_config.fixed_netmask_config);
	json_servconf["fixed_netmask"] = Json::Value(inet_ntoa(addr1.sin_addr));
	addr1.sin_addr.s_addr = ntohl(pEqpConfig->network_config.fixed_gateway_config);
	json_servconf["fixed_gateway"] = Json::Value(inet_ntoa(addr1.sin_addr));
	
	/************************************************************/

	/**********************SX1301_config***********************/
	Json::Value json_temp;	
	json_temp["lorawan_public"] = Json::Value(pGatewayconfig->SX1301_config.boardconf.lorawan_public);
	json_temp["clksrc"] = Json::Value(pGatewayconfig->SX1301_config.boardconf.clksrc);

	/******************* write radio json data ****************/
	Json::Value json_radio;
	char str[][10] = {"NONE", "SX1255", "SX1257"};
	int my_type = 0;
	int i;
	//for (i = 0; i < 2; ++i) {
	{
		json_temp["radio_1"] = json_radio;
		json_radio["enable"] = Json::Value(pGatewayconfig->SX1301_config.rfconf[0].enable);
		json_radio["freq"] = Json::Value(pGatewayconfig->SX1301_config.rfconf[0].freq_hz);
		json_radio["rssi_offset"] = Json::Value(pGatewayconfig->SX1301_config.rfconf[0].rssi_offset);		
		/*
		switch(pGatewayconfig->SX1301_config.rfconf[0].type)
		{
			case 0:
			sprintf(pGatewayconfig->SX1301_config.rfconf[0].str, "NONE");
			break;
			case 1:
			sprintf(pGatewayconfig->SX1301_config.rfconf[0].str, "SX1255");
			break;
			case 2:
			sprintf(pGatewayconfig->SX1301_config.rfconf[0].str, "SX1257");
			break;
		}
		*/
		my_type = pGatewayconfig->SX1301_config.rfconf[0].type;
		//json_radio["type"] = Json::Value(pGatewayconfig->SX1301_config.rfconf[0].str);
		json_radio["type"] = Json::Value(str[my_type]);
		json_radio["tx_enable"] = Json::Value(pGatewayconfig->SX1301_config.rfconf[0].tx_enable);
		/*
		//Jeffrey2018.05.10: new field
		if(pGatewayconfig->SX1301_config.rfconf[0].tx_enable){
			json_radio["tx_freq_min"] = Json::Value(pGatewayconfig->SX1301_config.rfconf[0].tx_freq_min);
			json_radio["tx_freq_max"] = Json::Value(pGatewayconfig->SX1301_config.rfconf[0].tx_freq_max);
		}
		*/

		json_temp["radio_0"] = json_radio;
		json_radio["enable"] = Json::Value(pGatewayconfig->SX1301_config.rfconf[1].enable);
		json_radio["freq"] = Json::Value(pGatewayconfig->SX1301_config.rfconf[1].freq_hz);
		json_radio["rssi_offset"] = Json::Value(pGatewayconfig->SX1301_config.rfconf[1].rssi_offset);
		//json_radio["type"] = Json::Value(pGatewayconfig->SX1301_config.rfconf[1].str);
		my_type = pGatewayconfig->SX1301_config.rfconf[1].type;		
		json_radio["type"] = Json::Value(str[my_type]);
		json_radio["tx_enable"] = Json::Value(pGatewayconfig->SX1301_config.rfconf[1].tx_enable);

		/*
		//Jeffrey2018.05.10: new field
		if(pGatewayconfig->SX1301_config.rfconf[1].tx_enable){
			json_radio["tx_freq_min"] = Json::Value(pGatewayconfig->SX1301_config.rfconf[1].tx_freq_min);
			json_radio["tx_freq_max"] = Json::Value(pGatewayconfig->SX1301_config.rfconf[1].tx_freq_max);
		}
		*/
	}

	/******************* write chan_multi json data ****************/
	Json::Value json_chan;
	for (i = 0; i < 3; ++i) {	
		json_temp["chan_multiSF_7"] = json_chan;
		json_chan["enable"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[0].enable);
		json_chan["radio"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[0].rf_chain);
		json_chan["if"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[0].freq_hz);
		
		json_temp["chan_multiSF_0"] = json_chan;
		json_chan["enable"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[1].enable);
		json_chan["radio"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[1].rf_chain);
		json_chan["if"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[1].freq_hz);

		json_temp["chan_multiSF_1"] = json_chan;
		json_chan["enable"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[2].enable);
		json_chan["radio"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[2].rf_chain);
		json_chan["if"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[2].freq_hz);

		json_temp["chan_multiSF_2"] = json_chan;
		json_chan["enable"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[3].enable);
		json_chan["radio"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[3].rf_chain);
		json_chan["if"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[3].freq_hz);

		json_temp["chan_multiSF_3"] = json_chan;
		json_chan["enable"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[4].enable);
		json_chan["radio"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[4].rf_chain);
		json_chan["if"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[4].freq_hz);

		json_temp["chan_multiSF_4"] = json_chan;
		json_chan["enable"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[5].enable);
		json_chan["radio"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[5].rf_chain);
		json_chan["if"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[5].freq_hz);

		json_temp["chan_multiSF_5"] = json_chan;
		json_chan["enable"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[6].enable);
		json_chan["radio"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[6].rf_chain);
		json_chan["if"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[6].freq_hz);

		json_temp["chan_multiSF_6"] = json_chan;
		json_chan["enable"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[7].enable);
		json_chan["radio"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[7].rf_chain);
		json_chan["if"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[7].freq_hz);
	}

		json_temp["chan_Lora_std"] = json_chan;
		json_chan["enable"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[9].enable);
		json_chan["radio"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[9].rf_chain);
		json_chan["if"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[9].freq_hz);
		json_chan["bandwidth"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[9].bandwidth);
		json_chan["datarate"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[9].datarate);

		json_temp["chan_FSK"] = json_chan;
		json_chan["enable"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[8].enable);
		json_chan["radio"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[8].rf_chain);
		json_chan["if"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[8].freq_hz);
		json_chan["bandwidth"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[8].bandwidth);
		json_chan["spread_factor"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[8].datarate);

		json_temp["chan_Lora_std"] = json_chan;
		json_chan["enable"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[9].enable);
		json_chan["radio"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[9].rf_chain);
		json_chan["if"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[9].freq_hz);
		json_chan["bandwidth"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[9].bandwidth);
		json_chan["datarate"] = Json::Value(pGatewayconfig->SX1301_config.ifconf[9].datarate);
	
	/******************* write tx_lut json data ****************/
	Json::Value json_tx_lut;
	for (i = 0; i < 2; ++i) {
		pGatewayconfig->SX1301_config.txlut.size++;
		json_temp["tx_lut_15"] = json_tx_lut;
		json_tx_lut["pa_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[0].pa_gain);
		json_tx_lut["mix_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[0].mix_gain);
		json_tx_lut["rf_power"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[0].rf_power);
		json_tx_lut["dig_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[0].dig_gain);

		json_temp["tx_lut_0"] = json_tx_lut;
		json_tx_lut["pa_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[1].pa_gain);
		json_tx_lut["mix_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[1].mix_gain);
		json_tx_lut["rf_power"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[1].rf_power);
		json_tx_lut["dig_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[1].dig_gain);

		json_temp["tx_lut_1"] = json_tx_lut;
		json_tx_lut["pa_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[2].pa_gain);
		json_tx_lut["mix_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[2].mix_gain);
		json_tx_lut["rf_power"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[2].rf_power);
		json_tx_lut["dig_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[2].dig_gain);

		json_temp["tx_lut_2"] = json_tx_lut;
		json_tx_lut["pa_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[3].pa_gain);
		json_tx_lut["mix_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[3].mix_gain);
		json_tx_lut["rf_power"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[3].rf_power);
		json_tx_lut["dig_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[3].dig_gain);

		json_temp["tx_lut_3"] = json_tx_lut;
		json_tx_lut["pa_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[4].pa_gain);
		json_tx_lut["mix_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[4].mix_gain);
		json_tx_lut["rf_power"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[4].rf_power);
		json_tx_lut["dig_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[4].dig_gain);

		json_temp["tx_lut_4"] = json_tx_lut;
		json_tx_lut["pa_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[5].pa_gain);
		json_tx_lut["mix_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[5].mix_gain);
		json_tx_lut["rf_power"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[5].rf_power);
		json_tx_lut["dig_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[5].dig_gain);

		json_temp["tx_lut_5"] = json_tx_lut;
		json_tx_lut["pa_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[6].pa_gain);
		json_tx_lut["mix_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[6].mix_gain);
		json_tx_lut["rf_power"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[6].rf_power);
		json_tx_lut["dig_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[6].dig_gain);

		json_temp["tx_lut_6"] = json_tx_lut;
		json_tx_lut["pa_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[7].pa_gain);
		json_tx_lut["mix_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[7].mix_gain);
		json_tx_lut["rf_power"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[7].rf_power);
		json_tx_lut["dig_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[7].dig_gain);

		json_temp["tx_lut_7"] = json_tx_lut;
		json_tx_lut["pa_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[8].pa_gain);
		json_tx_lut["mix_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[8].mix_gain);
		json_tx_lut["rf_power"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[8].rf_power);
		json_tx_lut["dig_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[8].dig_gain);

		json_temp["tx_lut_8"] = json_tx_lut;
		json_tx_lut["pa_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[9].pa_gain);
		json_tx_lut["mix_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[9].mix_gain);
		json_tx_lut["rf_power"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[9].rf_power);
		json_tx_lut["dig_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[9].dig_gain);

		json_temp["tx_lut_9"] = json_tx_lut;
		json_tx_lut["pa_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[10].pa_gain);
		json_tx_lut["mix_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[10].mix_gain);
		json_tx_lut["rf_power"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[10].rf_power);
		json_tx_lut["dig_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[10].dig_gain);

		json_temp["tx_lut_10"] = json_tx_lut;
		json_tx_lut["pa_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[11].pa_gain);
		json_tx_lut["mix_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[11].mix_gain);
		json_tx_lut["rf_power"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[11].rf_power);
		json_tx_lut["dig_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[11].dig_gain);

		json_temp["tx_lut_11"] = json_tx_lut;
		json_tx_lut["pa_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[12].pa_gain);
		json_tx_lut["mix_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[12].mix_gain);
		json_tx_lut["rf_power"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[12].rf_power);
		json_tx_lut["dig_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[12].dig_gain);

		json_temp["tx_lut_12"] = json_tx_lut;
		json_tx_lut["pa_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[13].pa_gain);
		json_tx_lut["mix_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[13].mix_gain);
		json_tx_lut["rf_power"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[13].rf_power);
		json_tx_lut["dig_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[13].dig_gain);

		json_temp["tx_lut_13"] = json_tx_lut;
		json_tx_lut["pa_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[14].pa_gain);
		json_tx_lut["mix_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[14].mix_gain);
		json_tx_lut["rf_power"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[14].rf_power);
		json_tx_lut["dig_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[14].dig_gain);


		json_temp["tx_lut_14"] = json_tx_lut;
		json_tx_lut["pa_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[15].pa_gain);
		json_tx_lut["mix_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[15].mix_gain);
		json_tx_lut["rf_power"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[15].rf_power);
		json_tx_lut["dig_gain"] = Json::Value(pGatewayconfig->SX1301_config.txlut.lut[15].dig_gain);
	}
	/**********************************************************************/
	
	Json::Value root; 
	root["SX1301_conf"] = json_temp; 
	root["gateway_conf"] = json_gateway; 
	root["serverIP_conf"] = json_servconf; 
	// Json::FastWriter fast_writer;
	// std::cout << fast_writer.write(root);
	
	Json::StyledWriter styled_writer;
	fout << styled_writer.write(root);
 
	fout << flush;
	fout.close();
}
