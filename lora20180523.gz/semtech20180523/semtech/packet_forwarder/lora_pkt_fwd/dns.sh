#!/bin/bash
cat /etc/resolv.conf|grep nameserver > dns_1
sed -n -f sedlist dns_1 > dns_2
sed -n '2p' dns_2 > Primary_dns
sed -n '5p' dns_2 > Secondary_dns
