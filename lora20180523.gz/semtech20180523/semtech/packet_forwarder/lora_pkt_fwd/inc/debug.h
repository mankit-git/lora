#ifndef __DEBUG_DEBUG_H
#define __DEBUG_DEBUG_H

void debug_init(void);


#endif
