#ifndef _IPCS_DEBUG_H_
#define _IPCS_DEBUG_H_ 

#include <stdarg.h>
#include <stdio.h>
#include <syslog.h>
//#define _DEBUG			1

/* Debug level masks */
#define DPRINTF_EVT_NONE	0x00000000
#define DPRINTF_EVT_ERROR	0x00000001
#define DPRINTF_EVT_WEB		0x00000002
#define DPRINTF_EVT_SIG		0x00000004
#define DPRINTF_EVT_MSG		0x00000010
#define DPRINTF_EVT_NETWORK	0x00000020
#define DPRINTF_EVT_UART	0x00000040
#define DPRINTF_EVT_FLASH	0x00000080
#define DPRINTF_EVT_CGI		0x00000100
#define DPRINTF_EVT_LLIST	0x00000200
#define DPRINTF_EVT_QUEUE	0x00000400
#define DPRINTF_EVT_THREAD	0x00000800
#define DPRINTF_EVT_DATA	0x00001000
#define DPRINTF_EVT_WIFI	0x00002000
#define DPRINTF_EVT_ALL		0xFFFFFFFF


/* debug level for this library */
//#define DPRINTF_LEVEL   DPRINTF_EVT_MSG
//#define DPRINTF_LEVEL	DPRINTF_EVT_UART
//#define DPRINTF_LEVEL	DPRINTF_EVT_NONE
//#define DPRINTF_LEVEL  DPRINTF_EVT_SIG
//#define DPRINTF_LEVEL	DPRINTF_EVT_FLASH
//#define DPRINTF_LEVEL	DPRINTF_EVT_CGI
#define DPRINTF_LEVEL	DPRINTF_EVT_ALL

/* Buffer size for msvc implementation because it outputs to DebugOutput */
#define DPRINTF_BUF_SZ  1024


//#define trace(fmt, args...) do{syslog(LOG_SYSLOG | LOG_NOTICE, "line %d : " fmt , __LINE__, ## args);} while(0)

//#define DPRINTF(int level, fmt, args...) do{ if(DPRINTF_LEVEL & level) { syslog(LOG_SYSLOG | LOG_NOTICE, "line %d : " fmt , __LINE__, ## args);}} while(0)
#if 0
static __inline void DPRINTF(int level, char *fmt, ...)
{
    if(DPRINTF_LEVEL & level)
    { 
    	va_list args;
    	char buf[DPRINTF_BUF_SZ];
    	va_start(args, fmt);
    	vsprintf(buf, fmt, args);
    	syslog(LOG_SYSLOG | LOG_NOTICE, "%s\n" ,buf);
    }	
}
#else
static __inline void DPRINTF(int level, char *fmt, ...)
{
	if (DPRINTF_LEVEL & level) 
	{
		va_list args;
		char buf[DPRINTF_BUF_SZ];
		va_start(args, fmt);
		vsprintf(buf, fmt, args);
		//OutputDebugString(buf);
		fprintf(stderr, "%s\n", buf);
	}
}
#endif
//#ifdef _DEBUG
//static __inline void DPRINTF(int level, char *fmt, ...)
//{
//	if (DPRINTF_LEVEL & level) 
//	{
//		va_list args;
//		char buf[DPRINTF_BUF_SZ];
//		va_start(args, fmt);
//		vsprintf(buf, fmt, args);
//		OutputDebugString(buf);
//		fprintf(stderr, "%s\n", buf);
//	}
//}
//#else
//static __inline void DPRINTF(int level, char *fmt, ...)
//{
//	if (DPRINTF_LEVEL & level) 
//	{
//		va_list args;
//		char buf[DPRINTF_BUF_SZ];
//		va_start(args, fmt);
//		vsprintf(buf, fmt, args);
//		//OutputDebugString(buf);
//		fprintf(stderr, "%s\n", buf);
//	}
//}
//#endif



#endif

