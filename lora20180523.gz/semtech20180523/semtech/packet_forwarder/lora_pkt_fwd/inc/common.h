#ifndef __COMMON_H
#define __COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/msg.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>

#define PROJ_PATH "/home/pi/fifo"
#define PROJ_ID   1

#define MSGSIZE 50

struct msgbuffer
{
	long mtype; // 消息队列中的消息的第一个成员必须是long

	char mtext[MSGSIZE]; // 消息的正文
};

#define J2R 1
#define R2J 2

#endif
