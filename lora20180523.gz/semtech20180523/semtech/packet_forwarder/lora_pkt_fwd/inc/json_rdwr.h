#ifndef _JSON_RDWR_H_
#define _JSON_RDWR_H_

#ifdef  __cplusplus  
extern "C" {  
#endif  

//#include "../../lora_gateway/libloragw/inc/loragw_hal.h"
#include "loragw_hal.h"

#define DEFAULT_SERVER		127.0.0.1 /* hostname also supported */
#define DEFAULT_PORT_UP		1780
#define DEFAULT_PORT_DW		1782
#define DEFAULT_KEEPALIVE	5	/* default time interval for downstream keep-alive packet */
#define DEFAULT_STAT		30	/* default time interval for statistics */
#define PUSH_TIMEOUT_MS		100
#define PULL_TIMEOUT_MS		200
#define GPS_REF_MAX_AGE		30	/* maximum admitted delay in seconds of GPS loss before considering latest GPS sync unusable */
#define FETCH_SLEEP_MS		10	/* nb of ms waited when a fetch return no packets */

#define MSG(args...)	printf(args) /* message that is destined to the user */
#define STRINGIFY(x)	#x
#define STR(x)			STRINGIFY(x)

#if 0

enum lgw_radio_type_e {
    LGW_RADIO_TYPE_NONE,
    LGW_RADIO_TYPE_SX1255,
    LGW_RADIO_TYPE_SX1257,
    LGW_RADIO_TYPE_SX1272,
    LGW_RADIO_TYPE_SX1276
};

/**
@struct lgw_conf_lbt_chan_s
@brief Configuration structure for LBT channels
*/
struct lgw_conf_lbt_chan_s {
    uint32_t freq_hz;
    uint16_t scan_time_us;
};

/**
@struct lgw_conf_lbt_s
@brief Configuration structure for LBT specificities
*/
struct lgw_conf_lbt_s {
    bool                        enable;             /*!> enable or disable LBT */
    int8_t                      rssi_target;        /*!> RSSI threshold to detect if channel is busy or not (dBm) */
    uint8_t                     nb_channel;         /*!> number of LBT channels */
    struct lgw_conf_lbt_chan_s  channels[LBT_CHANNEL_FREQ_NB];
    int8_t                      rssi_offset;        /*!> RSSI offset to be applied to SX127x RSSI values */
};

enum lgw_radio_type_e {
	LGW_RADIO_TYPE_NONE,
	LGW_RADIO_TYPE_SX1255,
	LGW_RADIO_TYPE_SX1257
};

/**
@struct lgw_conf_board_s
@brief Configuration structure for board specificities
*/
struct lgw_conf_board_s {
	bool		lorawan_public;		/*!> Enable ONLY for *public* networks using the LoRa MAC protocol */
	uint8_t		clksrc;			/*!> Index of RF chain which provides clock to concentrator */
}; // 1 + 1 = 2

/**
@struct lgw_conf_rxrf_s
@brief Configuration structure for a RF chain
*/
struct lgw_conf_rxrf_s {
	bool			enable;			/*!> enable or disable that RF chain */
	uint32_t		freq_hz;		/*!> center frequency of the radio in Hz */
	float			rssi_offset;		/*!> Board-specific RSSI correction factor */
	enum lgw_radio_type_e	type;			/*!> Radio type for that RF chain (SX1255, SX1257....) */
	bool			tx_enable;		/*!> enable or disable TX on that RF chain */
	uint32_t        tx_notch_freq;  /*!> TX notch filter frequency [126KHz..250KHz] */
}; // 1 + 4 + 4 + 1 + 1  = 11 (+ 4 = 15)

struct lgw_conf_rxrf_j {
	bool			enable;			/*!> enable or disable that RF chain */
	uint32_t		freq_hz;		/*!> center frequency of the radio in Hz */
	float			rssi_offset;	/*!> Board-specific RSSI correction factor */
	enum lgw_radio_type_e	type;	/*!> Radio type for that RF chain (SX1255, SX1257....) */
	bool			tx_enable;		/*!> enable or disable TX on that RF chain */
	uint32_t        tx_notch_freq;  /*!> TX notch filter frequency [126KHz..250KHz] */	
	//uint32_t        tx_freq_min;
	//uint32_t        tx_freq_max;
};

/**
@struct lgw_conf_rxif_s
@brief Configuration structure for an IF chain
*/
struct lgw_conf_rxif_s {
	bool		enable;			/*!> enable or disable that IF chain */
	uint8_t		rf_chain;		/*!> to which RF chain is that IF chain associated */
	int32_t		freq_hz;		/*!> center frequ of the IF chain, relative to RF chain frequency */
	//uint8_t		bandwidth;		/*!> RX bandwidth, 0 for default */
	uint32_t		bandwidth;		/*!> RX bandwidth, 0 for default */
	uint32_t	datarate;		/*!> RX datarate, 0 for default */
	uint8_t		sync_word_size;	/*!> size of FSK sync word (number of bytes, 0 for default) */
	uint64_t	sync_word;		/*!> FSK sync word (ALIGN RIGHT, eg. 0xC194C1) */
}; // 1 + 1 + 4 + 4 + 4 + 1 + 8 = 23 
 
/**
@struct lgw_tx_gain_s
@brief Structure containing all gains of Tx chain
*/
struct lgw_tx_gain_s {
	uint8_t		dig_gain;	/*!> 2 bits, control of the digital gain of SX1301 */
	uint8_t		pa_gain;	/*!> 2 bits, control of the external PA (SX1301 I/O) */
	uint8_t		dac_gain;	/*!> 2 bits, control of the radio DAC */
	uint8_t		mix_gain;	/*!> 4 bits, control of the radio mixer */
	int8_t		rf_power;	/*!> measured TX power at the board connector, in dBm */
}; // 1 + 1 + 1 + 1 + 1 = 5

/**
@struct lgw_tx_gain_lut_s
@brief Structure defining the Tx gain LUT
*/
struct lgw_tx_gain_lut_s {
	struct lgw_tx_gain_s	lut[TX_GAIN_LUT_SIZE_MAX];	/*!> Array of Tx gain struct */
	uint8_t			size;				/*!> Number of LUT indexes */
}; // 5*16 + 1 = 81

#endif



typedef struct _SX1301config
{
	struct lgw_conf_board_s boardconf; // 2
	struct lgw_conf_rxrf_s rfconf[2];  // 2 + 11 * 2  = 24;
	struct lgw_conf_rxif_s ifconf[10]; // 24 + 23 * 10 = 254
	struct lgw_tx_gain_lut_s txlut; // 254 + 81 = 335
} __attribute__((packed)) SX1301config; // 335

struct _Gateway_Conf
{
	char gateway_ID[20]; // 20
	// char server_address[20]; 
	char serv_addr[64]; // 20 + 64 = 84(e.g. accept format '192.168.1.2' only)
	// char serv_port_up[8];   /* server port for upstream traffic = STR(DEFAULT_PORT_UP),STR(DEFAULT_PORT_DW)*/
	// char serv_port_down[8]; /* server port for downstream traffic */
	unsigned short serv_port_up;  // 84 + 2 = 86
	unsigned short serv_port_down; // 86 + 2 = 88
	int keepalive_time; // 88 + 4 = 92/* send a PULL_DATA request every X seconds, negative = disabled */
	unsigned int stat_interval;  // 92 + 4 = 96

	//struct timeval push_timeout_half;
	int timeout; // 96 + 4 = 100

	bool fwd_valid_pkt; // 100 + 1 = 101 /* packets with PAYLOAD CRC OK are forwarded */
	bool fwd_error_pkt; // 101 + 1 = 102 /* packets with PAYLOAD CRC ERROR are NOT forwarded ={{0}, STR(DEFAULT_SERVER), 0, 0,DEFAULT_KEEPALIVE, DEFAULT_STAT, 0, true, false, false}*/
	bool fwd_nocrc_pkt;	// 102 + 1 = 103
} __attribute__((packed)) gateway_config; // 103


// if considering alignment, the size of the following structure

typedef struct _Gatewayconfig // sizeof(Gatewayconfig) = 584
{
	SX1301config SX1301_config; // 335 
	struct _Gateway_Conf gateway_config; // 335 + 103 = 438

} __attribute__((packed)) Gatewayconfig; // 438

Gatewayconfig* saGetGatewayconfig(void);

extern void json_rdwr(Gatewayconfig *pGatewayconfig, EqpConfig *pEqpConfig);

#ifdef  __cplusplus  
}  
#endif  /* end of __cplusplus */  


#endif
