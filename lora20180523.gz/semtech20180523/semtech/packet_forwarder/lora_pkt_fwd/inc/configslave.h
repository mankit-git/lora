#ifndef _CONFIGSLAVE_H_
#define _CONFIGSLAVE_H_

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <stdlib.h>

#include <sys/stat.h>
#include <sys/types.h>

//#define FIFO "/home/pi/lora/packet_forwarder/gps_pkt_fwd/src/myfifo"
#define FIFO "/home/pi/fifo/configfifo"
#endif
