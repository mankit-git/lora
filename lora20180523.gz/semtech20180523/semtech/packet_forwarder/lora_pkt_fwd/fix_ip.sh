#!/bin/bash
	echo "interface eth0" >> /etc/dhcpcd.conf
	echo "static ip_address=192.168.1.12" >> /etc/dhcpcd.conf
	echo "static domain_name_servers=255.255.255.0" >> /etc/dhcpcd.conf
	echo "static routers=192.168.1.1" >> /etc/dhcpcd.conf

#!/bin/bash
	echo "interface eth0" >> /etc/dhcpcd.conf
	echo "static ip_address=192.168.0.1" >> /etc/dhcpcd.conf
	echo "static domain_name_servers=255.255.255.0" >> /etc/dhcpcd.conf
	echo "static routers=192.168.0.254" >> /etc/dhcpcd.conf
