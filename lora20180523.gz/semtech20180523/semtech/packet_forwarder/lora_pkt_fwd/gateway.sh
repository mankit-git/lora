#!/bin/bash
route|grep default > gateway_1
sed -n -f sedlist gateway_1 > gateway_2
sed -n '2p' gateway_2 > gateway
